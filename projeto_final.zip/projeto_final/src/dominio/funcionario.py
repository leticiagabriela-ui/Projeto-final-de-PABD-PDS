from dataclasses import dataclass


@dataclass
class Funcionario:
    """Representa a entidade de dominio funcionario (tabela `funcionario` do banco).

    A chave primária no banco é `matricula_funcionario`, então não existe campo `id`.
    """

    matricula: str
    nome: str
    email: str
