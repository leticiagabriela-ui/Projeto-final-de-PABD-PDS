from dataclasses import dataclass


@dataclass
class Aluno:
    """Representa a entidade de dominio aluno (tabela `aluno` do banco).

    A chave primária no banco é `matricula_aluno`, então não existe campo `id`.
    """

    matricula: str
    nome: str
    email: str
