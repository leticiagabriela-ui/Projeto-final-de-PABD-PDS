from dataclasses import dataclass


@dataclass
class Livro:
    """Representa a entidade de dominio livro (tabela `livro` do banco).

    A chave primária no banco é `titulo`, então não existe campo `id`.
    """

    titulo: str
    isbn: str
    autor: str
    ano_publicacao: int
    quantidade: int
    genero: str
    editora: str
