from dataclasses import dataclass
from typing import Optional

# Valores permitidos para o atributo `status` do empréstimo.
STATUS_EMPRESTADO = "emprestado"
STATUS_DEVOLVIDO = "devolvido"
STATUS_ATRASADO = "atrasado"
STATUS_CANCELADO = "cancelado"

STATUS_VALIDOS = (STATUS_DEVOLVIDO, STATUS_EMPRESTADO, STATUS_ATRASADO, STATUS_CANCELADO)

# Status que significam que o exemplar do livro NAO esta na prateleira
# (o aluno esta com o livro em maos).
STATUS_LIVRO_EMPRESTADO = (STATUS_EMPRESTADO, STATUS_ATRASADO)

# Status que significam que o exemplar do livro esta disponivel novamente
# (foi devolvido ou o emprestimo foi cancelado).
STATUS_LIVRO_DISPONIVEL = (STATUS_DEVOLVIDO, STATUS_CANCELADO)


@dataclass
class Emprestimo:
    """Representa a entidade de dominio emprestimo (tabela `emprestimo` do banco).

    `id` é gerado automaticamente pelo banco (AUTO_INCREMENT), por isso é opcional.
    `matricula_aluno` referencia aluno(matricula_aluno) e `titulo` referencia livro(titulo).
    `status` indica a situação do empréstimo e deve ser um dos valores de `STATUS_VALIDOS`
    (devolvido, emprestado, atrasado ou cancelado).
    """

    matricula_aluno: str
    titulo: str
    data_emprestimo: str
    data_devolucao: str
    status: str = STATUS_EMPRESTADO
    id: Optional[int] = None
