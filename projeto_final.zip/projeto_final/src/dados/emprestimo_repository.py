from typing import Optional

import mysql.connector

from src.dominio.emprestimo import Emprestimo, STATUS_LIVRO_EMPRESTADO


class EmprestimoRepository:
    """Camada dados: acessa a tabela `emprestimo` (chave primaria: id, auto incremento).

    FKs: matricula_aluno -> aluno(matricula_aluno) e titulo -> livro(titulo).
    """

    def __init__(self, conexao: mysql.connector.MySQLConnection) -> None:
        self.conexao = conexao
        self._criar_tabela()

    def _criar_tabela(self) -> None:
        cursor = self.conexao.cursor()
        cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS emprestimo (
                id INT AUTO_INCREMENT PRIMARY KEY,
                matricula_aluno VARCHAR(15),
                titulo VARCHAR(100),
                data_emprestimo DATE,
                data_devolucao DATE,
                status ENUM('devolvido', 'emprestado', 'atrasado', 'cancelado') NOT NULL DEFAULT 'emprestado',
                FOREIGN KEY (matricula_aluno) REFERENCES aluno(matricula_aluno),
                FOREIGN KEY (titulo) REFERENCES livro(titulo)
            )
            """
        )
        self.conexao.commit()
        cursor.close()
        self._garantir_coluna_status()

    def _garantir_coluna_status(self) -> None:
        """Adiciona a coluna `status` caso a tabela já exista de uma versão anterior."""
        cursor = self.conexao.cursor()
        try:
            cursor.execute(
                "ALTER TABLE emprestimo ADD COLUMN status "
                "ENUM('devolvido', 'emprestado', 'atrasado', 'cancelado') "
                "NOT NULL DEFAULT 'emprestado'"
            )
            self.conexao.commit()
        except mysql.connector.Error:
            # Coluna já existe (ou outro erro que a criação da tabela já trataria).
            self.conexao.rollback()
        finally:
            cursor.close()

    def adicionar(self, emprestimo: Emprestimo) -> int:
        """Cadastra um novo emprestimo.

        Regra: so e possivel emprestar um livro se a quantidade de
        exemplares disponiveis for maior que zero (nao pode passar do
        limite). Ao emprestar (status inicial em STATUS_LIVRO_EMPRESTADO,
        ou seja 'emprestado'/'atrasado'), a quantidade do livro e
        decrementada em 1.
        """
        cursor = self.conexao.cursor()
        try:
            livro_sai_do_estoque = emprestimo.status in STATUS_LIVRO_EMPRESTADO

            if livro_sai_do_estoque:
                cursor.execute(
                    "SELECT quantidade FROM livro WHERE titulo = %s FOR UPDATE",
                    (emprestimo.titulo,),
                )
                linha_livro = cursor.fetchone()

                if linha_livro is None:
                    raise ValueError(f"O livro '{emprestimo.titulo}' não foi encontrado.")

                quantidade_disponivel = linha_livro[0]
                if quantidade_disponivel <= 0:
                    raise ValueError(
                        f"Não há exemplares disponíveis do livro '{emprestimo.titulo}' "
                        "para empréstimo."
                    )

            cursor.execute(
                "INSERT INTO emprestimo (matricula_aluno, titulo, data_emprestimo, data_devolucao, status) "
                "VALUES (%s, %s, %s, %s, %s)",
                (
                    emprestimo.matricula_aluno,
                    emprestimo.titulo,
                    emprestimo.data_emprestimo,
                    emprestimo.data_devolucao,
                    emprestimo.status,
                ),
            )
            novo_id = int(cursor.lastrowid)

            if livro_sai_do_estoque:
                cursor.execute(
                    "UPDATE livro SET quantidade = quantidade - 1 WHERE titulo = %s",
                    (emprestimo.titulo,),
                )

            self.conexao.commit()
            return novo_id
        except Exception:
            self.conexao.rollback()
            raise
        finally:
            cursor.close()

    def listar_todos(self) -> list[Emprestimo]:
        cursor = self.conexao.cursor(dictionary=True)
        cursor.execute(
            "SELECT id, matricula_aluno, titulo, data_emprestimo, data_devolucao, status "
            "FROM emprestimo ORDER BY id"
        )
        linhas = cursor.fetchall()
        cursor.close()
        return [
            Emprestimo(
                id=linha["id"],
                matricula_aluno=linha["matricula_aluno"],
                titulo=linha["titulo"],
                data_emprestimo=linha["data_emprestimo"],
                data_devolucao=linha["data_devolucao"],
                status=linha["status"],
            )
            for linha in linhas
        ]

    def buscar_por_id(self, id_emprestimo: int) -> Optional[Emprestimo]:
        cursor = self.conexao.cursor(dictionary=True)
        cursor.execute(
            "SELECT id, matricula_aluno, titulo, data_emprestimo, data_devolucao, status "
            "FROM emprestimo WHERE id = %s",
            (id_emprestimo,),
        )
        linha = cursor.fetchone()
        cursor.close()
        if linha is None:
            return None
        return Emprestimo(
            id=linha["id"],
            matricula_aluno=linha["matricula_aluno"],
            titulo=linha["titulo"],
            data_emprestimo=linha["data_emprestimo"],
            data_devolucao=linha["data_devolucao"],
            status=linha["status"],
        )

    def buscar_por_matricula_aluno(self, matricula_aluno: str) -> list[Emprestimo]:
        """Busca todos os empréstimos de um determinado aluno (usado na consulta)."""
        cursor = self.conexao.cursor(dictionary=True)
        cursor.execute(
            "SELECT id, matricula_aluno, titulo, data_emprestimo, data_devolucao, status "
            "FROM emprestimo WHERE matricula_aluno = %s ORDER BY id",
            (matricula_aluno,),
        )
        linhas = cursor.fetchall()
        cursor.close()
        return [
            Emprestimo(
                id=linha["id"],
                matricula_aluno=linha["matricula_aluno"],
                titulo=linha["titulo"],
                data_emprestimo=linha["data_emprestimo"],
                data_devolucao=linha["data_devolucao"],
                status=linha["status"],
            )
            for linha in linhas
        ]

    def atualizar(self, emprestimo: Emprestimo) -> bool:
        """Atualiza um emprestimo existente.

        Regra: quando o status muda de 'emprestado'/'atrasado' para
        'devolvido'/'cancelado', a quantidade do livro e incrementada em 1
        (o exemplar volta para a prateleira). Quando o status muda no
        sentido contrario (o livro volta a ser emprestado), a quantidade
        e decrementada em 1, desde que haja exemplar disponivel. Se o
        titulo do livro tambem for alterado, o ajuste e feito no livro
        antigo e no novo, separadamente.
        """
        cursor = self.conexao.cursor()
        try:
            cursor.execute(
                "SELECT titulo, status FROM emprestimo WHERE id = %s FOR UPDATE",
                (emprestimo.id,),
            )
            linha_atual = cursor.fetchone()
            if linha_atual is None:
                return False

            titulo_antigo, status_antigo = linha_atual
            livro_estava_emprestado = status_antigo in STATUS_LIVRO_EMPRESTADO
            livro_estara_emprestado = emprestimo.status in STATUS_LIVRO_EMPRESTADO

            # Se o livro vai passar a estar emprestado (nao estava antes,
            # ou mudou de titulo), verifica se ha exemplar disponivel.
            if livro_estara_emprestado and (
                not livro_estava_emprestado or titulo_antigo != emprestimo.titulo
            ):
                cursor.execute(
                    "SELECT quantidade FROM livro WHERE titulo = %s FOR UPDATE",
                    (emprestimo.titulo,),
                )
                linha_livro = cursor.fetchone()
                if linha_livro is None:
                    raise ValueError(f"O livro '{emprestimo.titulo}' não foi encontrado.")
                if linha_livro[0] <= 0:
                    raise ValueError(
                        f"Não há exemplares disponíveis do livro '{emprestimo.titulo}' "
                        "para empréstimo."
                    )

            cursor.execute(
                "UPDATE emprestimo SET matricula_aluno = %s, titulo = %s, "
                "data_emprestimo = %s, data_devolucao = %s, status = %s WHERE id = %s",
                (
                    emprestimo.matricula_aluno,
                    emprestimo.titulo,
                    emprestimo.data_emprestimo,
                    emprestimo.data_devolucao,
                    emprestimo.status,
                    emprestimo.id,
                ),
            )
            afetados = cursor.rowcount > 0

            if titulo_antigo == emprestimo.titulo:
                if livro_estava_emprestado and not livro_estara_emprestado:
                    cursor.execute(
                        "UPDATE livro SET quantidade = quantidade + 1 WHERE titulo = %s",
                        (titulo_antigo,),
                    )
                elif not livro_estava_emprestado and livro_estara_emprestado:
                    cursor.execute(
                        "UPDATE livro SET quantidade = quantidade - 1 WHERE titulo = %s",
                        (emprestimo.titulo,),
                    )
            else:
                if livro_estava_emprestado:
                    cursor.execute(
                        "UPDATE livro SET quantidade = quantidade + 1 WHERE titulo = %s",
                        (titulo_antigo,),
                    )
                if livro_estara_emprestado:
                    cursor.execute(
                        "UPDATE livro SET quantidade = quantidade - 1 WHERE titulo = %s",
                        (emprestimo.titulo,),
                    )

            self.conexao.commit()
            return afetados
        except Exception:
            self.conexao.rollback()
            raise
        finally:
            cursor.close()

    def remover(self, id_emprestimo: int) -> bool:
        """Remove um emprestimo.

        Se o emprestimo removido estava com status 'emprestado' ou
        'atrasado' (o exemplar ainda estava com o aluno), a quantidade
        do livro e devolvida (+1) ao ser excluido o registro.
        """
        cursor = self.conexao.cursor()
        try:
            cursor.execute(
                "SELECT titulo, status FROM emprestimo WHERE id = %s FOR UPDATE",
                (id_emprestimo,),
            )
            linha_atual = cursor.fetchone()

            cursor.execute(
                "DELETE FROM emprestimo WHERE id = %s",
                (id_emprestimo,),
            )
            afetados = cursor.rowcount > 0

            if afetados and linha_atual is not None:
                titulo, status = linha_atual
                if status in STATUS_LIVRO_EMPRESTADO:
                    cursor.execute(
                        "UPDATE livro SET quantidade = quantidade + 1 WHERE titulo = %s",
                        (titulo,),
                    )

            self.conexao.commit()
            return afetados
        except Exception:
            self.conexao.rollback()
            raise
        finally:
            cursor.close()
