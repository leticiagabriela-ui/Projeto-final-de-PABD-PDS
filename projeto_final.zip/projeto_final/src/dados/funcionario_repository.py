from typing import Optional

import mysql.connector

from src.dominio.funcionario import Funcionario


class FuncionarioRepository:
    """Camada dados: acessa a tabela `funcionario` (chave primaria: matricula_funcionario)."""

    def __init__(self, conexao: mysql.connector.MySQLConnection) -> None:
        self.conexao = conexao
        self._criar_tabela()

    def _criar_tabela(self) -> None:
        cursor = self.conexao.cursor()
        cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS funcionario (
                nome VARCHAR(100) NOT NULL,
                matricula_funcionario VARCHAR(50) NOT NULL PRIMARY KEY,
                email VARCHAR(100)
            )
            """
        )
        self.conexao.commit()
        cursor.close()

    def adicionar(self, funcionario: Funcionario) -> None:
        cursor = self.conexao.cursor()
        cursor.execute(
            "INSERT INTO funcionario (nome, matricula_funcionario, email) VALUES (%s, %s, %s)",
            (funcionario.nome, funcionario.matricula, funcionario.email),
        )
        self.conexao.commit()
        cursor.close()

    def listar_todos(self) -> list[Funcionario]:
        cursor = self.conexao.cursor(dictionary=True)
        cursor.execute(
            "SELECT nome, matricula_funcionario, email FROM funcionario ORDER BY matricula_funcionario"
        )
        linhas = cursor.fetchall()
        cursor.close()
        return [
            Funcionario(nome=linha["nome"], matricula=linha["matricula_funcionario"], email=linha["email"])
            for linha in linhas
        ]

    def buscar_por_matricula(self, matricula_funcionario: str) -> Optional[Funcionario]:
        cursor = self.conexao.cursor(dictionary=True)
        cursor.execute(
            "SELECT nome, matricula_funcionario, email FROM funcionario WHERE matricula_funcionario = %s",
            (matricula_funcionario,),
        )
        linha = cursor.fetchone()
        cursor.close()
        if linha is None:
            return None
        return Funcionario(nome=linha["nome"], matricula=linha["matricula_funcionario"], email=linha["email"])

    def atualizar(self, funcionario: Funcionario) -> bool:
        cursor = self.conexao.cursor()
        cursor.execute(
            "UPDATE funcionario SET nome = %s, email = %s WHERE matricula_funcionario = %s",
            (funcionario.nome, funcionario.email, funcionario.matricula),
        )
        self.conexao.commit()
        afetados = cursor.rowcount > 0
        cursor.close()
        return afetados

    def remover(self, matricula_funcionario: str) -> bool:
        cursor = self.conexao.cursor()
        cursor.execute(
            "DELETE FROM funcionario WHERE matricula_funcionario = %s",
            (matricula_funcionario,),
        )
        self.conexao.commit()
        afetados = cursor.rowcount > 0
        cursor.close()
        return afetados
