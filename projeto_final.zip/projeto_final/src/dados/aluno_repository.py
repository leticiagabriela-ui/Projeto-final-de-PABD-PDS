from typing import Optional

import mysql.connector

from src.dominio.aluno import Aluno


class AlunoRepository:
    """Camada dados: acessa a tabela `aluno` (chave primaria: matricula_aluno)."""

    def __init__(self, conexao: mysql.connector.MySQLConnection) -> None:
        self.conexao = conexao
        self._criar_tabela()

    def _criar_tabela(self) -> None:
        cursor = self.conexao.cursor()
        cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS aluno (
                matricula_aluno VARCHAR(15) NOT NULL PRIMARY KEY,
                nome_aluno VARCHAR(100) NOT NULL,
                email VARCHAR(50) NOT NULL
            )
            """
        )
        self.conexao.commit()
        cursor.close()

    def adicionar(self, aluno: Aluno) -> None:
        cursor = self.conexao.cursor()
        cursor.execute(
            "INSERT INTO aluno (matricula_aluno, nome_aluno, email) VALUES (%s, %s, %s)",
            (aluno.matricula, aluno.nome, aluno.email),
        )
        self.conexao.commit()
        cursor.close()

    def listar_todos(self) -> list[Aluno]:
        cursor = self.conexao.cursor(dictionary=True)
        cursor.execute(
            "SELECT matricula_aluno, nome_aluno, email FROM aluno ORDER BY matricula_aluno"
        )
        linhas = cursor.fetchall()
        cursor.close()
        return [
            Aluno(matricula=linha["matricula_aluno"], nome=linha["nome_aluno"], email=linha["email"])
            for linha in linhas
        ]

    def buscar_por_matricula(self, matricula_aluno: str) -> Optional[Aluno]:
        cursor = self.conexao.cursor(dictionary=True)
        cursor.execute(
            "SELECT matricula_aluno, nome_aluno, email FROM aluno WHERE matricula_aluno = %s",
            (matricula_aluno,),
        )
        linha = cursor.fetchone()
        cursor.close()
        if linha is None:
            return None
        return Aluno(matricula=linha["matricula_aluno"], nome=linha["nome_aluno"], email=linha["email"])

    def atualizar(self, aluno: Aluno) -> bool:
        cursor = self.conexao.cursor()
        cursor.execute(
            "UPDATE aluno SET nome_aluno = %s, email = %s WHERE matricula_aluno = %s",
            (aluno.nome, aluno.email, aluno.matricula),
        )
        self.conexao.commit()
        afetados = cursor.rowcount > 0
        cursor.close()
        return afetados

    def remover(self, matricula_aluno: str) -> bool:
        """Remove um aluno, se possivel.

        Regra: o aluno so pode ser excluido se ele NAO possuir nenhum
        emprestimo com status diferente de 'devolvido' ou 'cancelado'
        (ou seja, nao pode ter emprestimo em aberto/atrasado).
        Caso todos os emprestimos estejam finalizados ('devolvido' ou
        'cancelado'), o historico desses emprestimos e removido junto
        com o aluno, para nao violar a chave estrangeira da tabela
        `emprestimo`.
        """
        cursor = self.conexao.cursor()
        try:
            cursor.execute(
                "SELECT COUNT(*) FROM emprestimo "
                "WHERE matricula_aluno = %s AND status NOT IN ('devolvido', 'cancelado')",
                (matricula_aluno,),
            )
            (emprestimos_ativos,) = cursor.fetchone()

            if emprestimos_ativos > 0:
                raise ValueError(
                    "Não é possível excluir o aluno: ele possui empréstimo(s) "
                    "com status diferente de 'devolvido' ou 'cancelado'."
                )

            # Remove o historico de emprestimos ja finalizados desse aluno,
            # para nao violar a foreign key ao excluir o aluno.
            cursor.execute(
                "DELETE FROM emprestimo WHERE matricula_aluno = %s",
                (matricula_aluno,),
            )

            cursor.execute(
                "DELETE FROM aluno WHERE matricula_aluno = %s",
                (matricula_aluno,),
            )
            afetados = cursor.rowcount > 0

            self.conexao.commit()
            return afetados
        except Exception:
            self.conexao.rollback()
            raise
        finally:
            cursor.close()
