from typing import Optional

import mysql.connector

from src.dominio.livro import Livro


class LivroRepository:
    """Camada dados: acessa a tabela `livro` (chave primaria: titulo)."""

    def __init__(self, conexao: mysql.connector.MySQLConnection) -> None:
        self.conexao = conexao
        self._criar_tabela()

    def _criar_tabela(self) -> None:
        cursor = self.conexao.cursor()
        cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS livro (
                titulo VARCHAR(100) NOT NULL PRIMARY KEY,
                isbn VARCHAR(20) NOT NULL,
                autor VARCHAR(100) NOT NULL,
                ano_publicacao INT,
                quantidade INT NOT NULL,
                genero VARCHAR(50),
                editora VARCHAR(100) NOT NULL
            )
            """
        )
        self.conexao.commit()
        cursor.close()

    def adicionar(self, livro: Livro) -> None:
        cursor = self.conexao.cursor()
        cursor.execute(
            "INSERT INTO livro (titulo, isbn, autor, ano_publicacao, quantidade, genero, editora) "
            "VALUES (%s, %s, %s, %s, %s, %s, %s)",
            (
                livro.titulo,
                livro.isbn,
                livro.autor,
                livro.ano_publicacao,
                livro.quantidade,
                livro.genero,
                livro.editora,
            ),
        )
        self.conexao.commit()
        cursor.close()

    def listar_todos(self) -> list[Livro]:
        cursor = self.conexao.cursor(dictionary=True)
        cursor.execute(
            "SELECT titulo, isbn, autor, ano_publicacao, quantidade, genero, editora "
            "FROM livro ORDER BY titulo"
        )
        linhas = cursor.fetchall()
        cursor.close()
        return [
            Livro(
                titulo=linha["titulo"],
                isbn=linha["isbn"],
                autor=linha["autor"],
                ano_publicacao=linha["ano_publicacao"],
                quantidade=int(linha["quantidade"]),
                genero=linha["genero"],
                editora=linha["editora"],
            )
            for linha in linhas
        ]

    def buscar_por_titulo(self, titulo: str) -> Optional[Livro]:
        cursor = self.conexao.cursor(dictionary=True)
        cursor.execute(
            "SELECT titulo, isbn, autor, ano_publicacao, quantidade, genero, editora "
            "FROM livro WHERE titulo = %s",
            (titulo,),
        )
        linha = cursor.fetchone()
        cursor.close()
        if linha is None:
            return None
        return Livro(
            titulo=linha["titulo"],
            isbn=linha["isbn"],
            autor=linha["autor"],
            ano_publicacao=linha["ano_publicacao"],
            quantidade=int(linha["quantidade"]),
            genero=linha["genero"],
            editora=linha["editora"],
        )

    def atualizar(self, livro: Livro) -> bool:
        cursor = self.conexao.cursor()
        cursor.execute(
            "UPDATE livro SET isbn = %s, autor = %s, ano_publicacao = %s, "
            "quantidade = %s, genero = %s, editora = %s WHERE titulo = %s",
            (
                livro.isbn,
                livro.autor,
                livro.ano_publicacao,
                livro.quantidade,
                livro.genero,
                livro.editora,
                livro.titulo,
            ),
        )
        self.conexao.commit()
        afetados = cursor.rowcount > 0
        cursor.close()
        return afetados

    def possui_emprestimo_ativo(self, titulo: str) -> bool:
        """Verifica se existe empréstimo em aberto (emprestado ou atrasado) para o título."""
        cursor = self.conexao.cursor()
        cursor.execute(
            "SELECT 1 FROM emprestimo WHERE titulo = %s "
            "AND status IN ('emprestado', 'atrasado') LIMIT 1",
            (titulo,),
        )
        encontrado = cursor.fetchone() is not None
        cursor.close()
        return encontrado

    def remover(self, titulo: str) -> bool:
        """Remove um livro do catálogo.

        Regra: só é possível excluir o livro se não houver nenhum
        empréstimo em aberto (status 'emprestado' ou 'atrasado') para
        ele. Registros de empréstimo já finalizados (status 'devolvido'
        ou 'cancelado') não impedem a exclusão do livro; eles são
        removidos junto, já que passariam a referenciar um livro
        inexistente (a tabela `emprestimo` possui FK para `livro`).
        """
        cursor = self.conexao.cursor()
        try:
            cursor.execute(
                "SELECT 1 FROM emprestimo WHERE titulo = %s "
                "AND status IN ('emprestado', 'atrasado') LIMIT 1",
                (titulo,),
            )
            if cursor.fetchone() is not None:
                raise ValueError(
                    f"Não é possível excluir o livro '{titulo}': "
                    "há empréstimo(s) em aberto (emprestado ou atrasado) para ele."
                )

            cursor.execute(
                "DELETE FROM emprestimo WHERE titulo = %s",
                (titulo,),
            )

            cursor.execute(
                "DELETE FROM livro WHERE titulo = %s",
                (titulo,),
            )
            afetados = cursor.rowcount > 0

            self.conexao.commit()
            return afetados
        except Exception:
            self.conexao.rollback()
            raise
        finally:
            cursor.close()
