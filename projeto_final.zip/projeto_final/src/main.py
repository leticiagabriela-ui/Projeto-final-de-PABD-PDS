import os
import sys

# Garante que a raiz do projeto esteja no sys.path, independente de como
# este arquivo for executado (python src/main.py, python -m src.main, etc.).
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.dados.conexao_singleton import ConexaoSingleton
from src.dados.livro_repository import LivroRepository
from src.dados.aluno_repository import AlunoRepository
from src.dados.emprestimo_repository import EmprestimoRepository
from src.negocio.livro_service import LivroService
from src.negocio.aluno_service import AlunoService
from src.negocio.emprestimo_service import EmprestimoService
from src.apresentacao.interface_terminal import InterfaceTerminal


def principal() -> None:
    conexao = ConexaoSingleton.obter_conexao(
        tipo_banco="mysql",
        host="127.0.0.1",
        porta=3306,
        usuario="root",
        senha="labinfo",
        banco="biblioteca",
    )

    repositorio_livro = LivroRepository(conexao)
    repositorio_aluno = AlunoRepository(conexao)
    repositorio_emprestimo = EmprestimoRepository(conexao)

    servico_livro = LivroService(repositorio_livro)
    servico_aluno = AlunoService(repositorio_aluno)
    servico_emprestimo = EmprestimoService(repositorio_emprestimo)

    interface = InterfaceTerminal(servico_livro, servico_aluno, servico_emprestimo)

    try:
        interface.executar()
    finally:
        ConexaoSingleton.fechar_conexao()


if __name__ == "__main__":
    principal()
