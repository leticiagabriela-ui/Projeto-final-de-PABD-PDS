import tkinter as tk
from tkinter import messagebox
from src.apresentacao.Tkinter.widgets import BotaoRedondo

from src.dados.conexao_singleton import ConexaoSingleton
from src.dados.livro_repository import LivroRepository
import src.apresentacao.Tkinter.utils as ut


class JanelaExcluirLivro:
    def __init__(self, janela):
        self.frame = tk.Frame(janela)
        self.frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)

        tk.Label(self.frame, text="Excluir Livro", font=("Arial", 14, "bold")).grid(
            row=0, column=0, columnspan=2, pady=(0, 15)
        )

        tk.Label(self.frame, text="Título do Livro:").grid(row=1, column=0, sticky='E', padx=5, pady=5)
        self.entrada_titulo = tk.Entry(self.frame)
        self.entrada_titulo.grid(row=1, column=1, sticky='W', padx=5, pady=5)

        BotaoRedondo(self.frame, text="Excluir", command=self.excluir_livro).grid(
            row=2, column=0, columnspan=2, padx=5, pady=10
        )

        self.entrada_titulo.focus()

    def excluir_livro(self):
        titulo = self.entrada_titulo.get().strip()
        if not titulo:
            messagebox.showwarning("Atenção", "Informe o título do livro.")
            return

        confirmar = messagebox.askyesno(
            "Confirmar", f"Tem certeza que deseja excluir o livro '{titulo}'?"
        )
        if not confirmar:
            return

        resultado = False
        try:
            conexao = ConexaoSingleton.obter_conexao(
                tipo_banco="mysql",
                host="127.0.0.1",
                porta=3306,
                usuario="root",
                senha="labmari",
                banco="biblioteca",
            )
            repositorio = LivroRepository(conexao)
            resultado = repositorio.remover(titulo)
        except ValueError as erro:
            messagebox.showwarning("Não é possível excluir", str(erro))
            return
        except Exception as erro:
            messagebox.showerror("Erro", f"Não foi possível excluir o livro.\n{erro}")
            return

        ut.exibir_mensagem(resultado, "Livro excluído com sucesso!", "Livro não encontrado.")

        if resultado:
            self.entrada_titulo.delete(0, 'end')
            self.entrada_titulo.focus()
