import tkinter as tk
from tkinter import ttk, messagebox
from src.apresentacao.Tkinter.widgets import BotaoRedondo

from src.dados.conexao_singleton import ConexaoSingleton
from src.dados.livro_repository import LivroRepository
from src.dominio.livro import Livro


class JanelaConsultarLivro:
    def __init__(self, janela):
        self.livro_atual = None

        self.frame = tk.Frame(janela)
        self.frame.pack(fill="both", expand=True, padx=20, pady=20)

        tk.Label(self.frame, text="Consultar Livro", font=("Arial", 14, "bold")).pack(pady=(0, 15))

        # --- Campo de busca (somente título) ---
        frame_busca = tk.Frame(self.frame)
        frame_busca.pack(fill="x", pady=(0, 10))

        tk.Label(frame_busca, text="Título:").pack(side="left")

        self.termo_busca = tk.StringVar()
        entrada_busca = tk.Entry(frame_busca, textvariable=self.termo_busca)
        entrada_busca.pack(side="left", fill="x", expand=True, padx=(5, 5))
        entrada_busca.bind("<Return>", lambda evento: self.buscar_livro())

        BotaoRedondo(frame_busca, text="Buscar", command=self.buscar_livro).pack(side="left")
        BotaoRedondo(frame_busca, text="Limpar", command=self.limpar_busca).pack(side="left", padx=(5, 0))

        # --- Lista de resultado da busca ---
        colunas = ("titulo", "isbn", "autor", "ano_publicacao", "quantidade", "genero", "editora")
        self.tabela = ttk.Treeview(self.frame, columns=colunas, show="headings", height=5)

        titulos = {
            "titulo": "Título",
            "isbn": "ISBN",
            "autor": "Autor",
            "ano_publicacao": "Ano",
            "quantidade": "Qtd.",
            "genero": "Gênero",
            "editora": "Editora",
        }
        for coluna in colunas:
            self.tabela.heading(coluna, text=titulos[coluna])
            self.tabela.column(coluna, width=100, anchor="center")

        self.tabela.pack(fill="x", pady=(0, 20))

        # --- Área de edição (habilitada após encontrar o livro) ---
        frame_edicao = tk.LabelFrame(self.frame, text="Atualizar dados do livro encontrado")
        frame_edicao.pack(fill="x", padx=5, pady=5)

        campos = [
            ("ISBN:", "entrada_isbn"),
            ("Autor:", "entrada_autor"),
            ("Ano de publicação:", "entrada_ano"),
            ("Quantidade:", "entrada_quantidade"),
            ("Gênero:", "entrada_genero"),
            ("Editora:", "entrada_editora"),
        ]
        for i, (rotulo, nome_atributo) in enumerate(campos):
            tk.Label(frame_edicao, text=rotulo).grid(row=i, column=0, sticky="E", padx=5, pady=5)
            entrada = tk.Entry(frame_edicao, state="disabled")
            entrada.grid(row=i, column=1, sticky="EW", padx=5, pady=5)
            setattr(self, nome_atributo, entrada)

        frame_edicao.columnconfigure(1, weight=1)

        self.botao_salvar = BotaoRedondo(
            frame_edicao, text="Salvar Alterações", command=self.atualizar_livro, state="disabled"
        )
        self.botao_salvar.grid(row=len(campos), column=0, columnspan=2, pady=10)

        entrada_busca.focus()

    def limpar_busca(self):
        self.termo_busca.set("")
        for linha in self.tabela.get_children():
            self.tabela.delete(linha)
        self.livro_atual = None
        self._definir_campos_edicao(habilitado=False)

    def _preencher_entrada(self, entrada, valor, habilitado):
        estado = "normal" if habilitado else "disabled"
        entrada.configure(state="normal")
        entrada.delete(0, "end")
        if valor is not None:
            entrada.insert(0, str(valor))
        entrada.configure(state=estado)

    def _definir_campos_edicao(self, habilitado, livro=None):
        self._preencher_entrada(self.entrada_isbn, livro.isbn if livro else None, habilitado)
        self._preencher_entrada(self.entrada_autor, livro.autor if livro else None, habilitado)
        self._preencher_entrada(self.entrada_ano, livro.ano_publicacao if livro else None, habilitado)
        self._preencher_entrada(self.entrada_quantidade, livro.quantidade if livro else None, habilitado)
        self._preencher_entrada(self.entrada_genero, livro.genero if livro else None, habilitado)
        self._preencher_entrada(self.entrada_editora, livro.editora if livro else None, habilitado)
        self.botao_salvar.configure(state="normal" if habilitado else "disabled")

    def buscar_livro(self):
        for linha in self.tabela.get_children():
            self.tabela.delete(linha)

        titulo = self.termo_busca.get().strip()
        if not titulo:
            messagebox.showwarning("Atenção", "Informe o título do livro.")
            return

        try:
            conexao = ConexaoSingleton.obter_conexao(
                tipo_banco="mysql",
                host="127.0.0.1",
                porta=3306,
                usuario="root",
                senha="labmari",
                banco="biblioteca",
            )
            repositorio = LivroRepository(conexao)
            livro = repositorio.buscar_por_titulo(titulo)
        except Exception as erro:
            messagebox.showerror("Erro", f"Não foi possível consultar o livro.\n{erro}")
            return

        if livro is None:
            self.tabela.insert("", "end", values=("Nenhum livro encontrado", "", "", "", "", "", ""))
            self.livro_atual = None
            self._definir_campos_edicao(habilitado=False)
            return

        self.tabela.insert("", "end", values=(
            livro.titulo, livro.isbn, livro.autor, livro.ano_publicacao,
            livro.quantidade, livro.genero, livro.editora,
        ))
        self.livro_atual = livro
        self._definir_campos_edicao(habilitado=True, livro=livro)

    def atualizar_livro(self):
        if self.livro_atual is None:
            messagebox.showwarning("Atenção", "Busque um livro pelo título antes de salvar.")
            return

        isbn = self.entrada_isbn.get().strip()
        autor = self.entrada_autor.get().strip()
        ano_texto = self.entrada_ano.get().strip()
        quantidade_texto = self.entrada_quantidade.get().strip()
        genero = self.entrada_genero.get().strip()
        editora = self.entrada_editora.get().strip()

        if not isbn or not autor or not ano_texto or not quantidade_texto or not genero or not editora:
            messagebox.showwarning("Atenção", "Preencha todos os campos!")
            return

        try:
            ano_publicacao = int(ano_texto)
            quantidade = int(quantidade_texto)
        except ValueError:
            messagebox.showwarning("Atenção", "Ano de publicação e quantidade devem ser números inteiros.")
            return

        livro_atualizado = Livro(
            titulo=self.livro_atual.titulo,
            isbn=isbn,
            autor=autor,
            ano_publicacao=ano_publicacao,
            quantidade=quantidade,
            genero=genero,
            editora=editora,
        )

        try:
            conexao = ConexaoSingleton.obter_conexao(
                tipo_banco="mysql",
                host="127.0.0.1",
                porta=3306,
                usuario="root",
                senha="labinfo",
                banco="biblioteca",
            )
            repositorio = LivroRepository(conexao)
            resultado = repositorio.atualizar(livro_atualizado)
        except Exception as erro:
            messagebox.showerror("Erro", f"Não foi possível atualizar o livro.\n{erro}")
            return

        if resultado:
            messagebox.showinfo("Sucesso", "Livro atualizado com sucesso!")
            self.livro_atual = livro_atualizado
            self.buscar_livro()
        else:
            messagebox.showerror("Erro", "Não foi possível atualizar o livro.")
