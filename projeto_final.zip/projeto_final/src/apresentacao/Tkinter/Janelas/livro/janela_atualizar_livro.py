import tkinter as tk
from tkinter import messagebox
from src.apresentacao.Tkinter.widgets import BotaoRedondo

from src.dados.conexao_singleton import ConexaoSingleton
from src.dados.livro_repository import LivroRepository
from src.dominio.livro import Livro
import src.apresentacao.Tkinter.utils as ut


class JanelaAtualizarLivro:
    def __init__(self, janela):
        self.livro_atual = None

        self.frame = tk.Frame(janela)
        self.frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)

        tk.Label(self.frame, text="Atualizar Livro", font=("Arial", 14, "bold")).grid(
            row=0, column=0, columnspan=3, pady=(0, 15)
        )

        tk.Label(self.frame, text="Titulo do Livro:").grid(row=1, column=0, sticky='E', padx=5, pady=5)
        self.entrada_titulo_busca = tk.Entry(self.frame)
        self.entrada_titulo_busca.grid(row=1, column=1, sticky='W', padx=5, pady=5)
        BotaoRedondo(self.frame, text="Buscar", command=self.buscar_livro).grid(row=1, column=2, padx=5, pady=5)

        tk.Label(self.frame, text="isbn:").grid(row=2, column=0, sticky='E', padx=5, pady=5)
        self.entrada_isbn = tk.Entry(self.frame)
        self.entrada_isbn.grid(row=2, column=1, sticky='W', padx=5, pady=5)

        tk.Label(self.frame, text="autor:").grid(row=3, column=0, sticky='E', padx=5, pady=5)
        self.entrada_autor = tk.Entry(self.frame)
        self.entrada_autor.grid(row=3, column=1, sticky='W', padx=5, pady=5)

        tk.Label(self.frame, text="ano_publicacao:").grid(row=4, column=0, sticky='E', padx=5, pady=5)
        self.entrada_ano_publicacao = tk.Entry(self.frame)
        self.entrada_ano_publicacao.grid(row=4, column=1, sticky='W', padx=5, pady=5)

        tk.Label(self.frame, text="Quantidade:").grid(row=5, column=0, sticky='E', padx=5, pady=5)
        self.entrada_quantidade = tk.Entry(self.frame)
        self.entrada_quantidade.grid(row=5, column=1, sticky='W', padx=5, pady=5)

        tk.Label(self.frame, text="genero:").grid(row=6, column=0, sticky='E', padx=5, pady=5)
        self.entrada_genero = tk.Entry(self.frame)
        self.entrada_genero.grid(row=6, column=1, sticky='W', padx=5, pady=5)

        tk.Label(self.frame, text="editora:").grid(row=7, column=0, sticky='E', padx=5, pady=5)
        self.entrada_editora = tk.Entry(self.frame)
        self.entrada_editora.grid(row=7, column=1, sticky='W', padx=5, pady=5)

        BotaoRedondo(self.frame, text="Salvar Alterações", command=self.atualizar_livro).grid(
            row=8, column=0, columnspan=3, padx=5, pady=10
        )

        self.entrada_titulo_busca.focus()

    def limpar_campos_dados(self):
        self.entrada_isbn.delete(0, 'end')
        self.entrada_autor.delete(0, 'end')
        self.entrada_ano_publicacao.delete(0, 'end')
        self.entrada_quantidade.delete(0, 'end')
        self.entrada_genero.delete(0, 'end')
        self.entrada_editora.delete(0, 'end')

    def preencher_campos(self, livro):
        self.limpar_campos_dados()
        self.entrada_isbn.insert(0, livro.isbn)
        self.entrada_autor.insert(0, livro.autor)
        self.entrada_ano_publicacao.insert(0, livro.ano_publicacao)
        self.entrada_quantidade.insert(0, livro.quantidade)
        self.entrada_genero.insert(0, livro.genero)
        self.entrada_editora.insert(0, livro.editora)

    def buscar_livro(self):
        titulo = self.entrada_titulo_busca.get().strip()
        if not titulo:
            messagebox.showwarning("Atenção", "Informe o título do livro.")
            return

        try:
            conexao = ConexaoSingleton.obter_conexao(
                tipo_banco="mysql",
                host="127.0.0.1",
                porta=3306,
                usuario="root",
                senha="labmari",
                banco="biblioteca",
            )
            repositorio = LivroRepository(conexao)
            livro = repositorio.buscar_por_titulo(titulo)
        except Exception as erro:
            messagebox.showerror("Erro", f"Não foi possível buscar o livro.\n{erro}")
            return

        if livro is None:
            messagebox.showwarning("Atenção", "Livro não encontrado.")
            self.livro_atual = None
            self.limpar_campos_dados()
            return

        self.livro_atual = livro
        self.preencher_campos(livro)

    def atualizar_livro(self):
        if self.livro_atual is None:
            messagebox.showwarning("Atenção", "Busque um livro pelo título antes de salvar.")
            return

        isbn = self.entrada_isbn.get().strip()
        autor = self.entrada_autor.get().strip()
        ano_publicacao = self.entrada_ano_publicacao.get().strip()
        quantidade = self.entrada_quantidade.get().strip()
        genero = self.entrada_genero.get().strip()
        editora = self.entrada_editora.get().strip()

        if not isbn or not autor or not ano_publicacao or not quantidade or not genero or not editora:
            messagebox.showwarning("Atenção", "Preencha todos os campos!")
            return

        try:
            ano_publicacao = int(ano_publicacao)
        except ValueError:
            messagebox.showerror("Erro", "ano_publicacao deve ser número inteiro.")
            return

        try:
            quantidade = int(quantidade)
        except ValueError:
            messagebox.showerror("Erro", "quantidade deve ser número inteiro.")
            return

        livro = Livro(
            titulo=self.livro_atual.titulo,
            isbn=isbn,
            autor=autor,
            ano_publicacao=ano_publicacao,
            quantidade=quantidade,
            genero=genero,
            editora=editora,
        )

        resultado = False
        try:
            conexao = ConexaoSingleton.obter_conexao(
                tipo_banco="mysql",
                host="127.0.0.1",
                porta=3306,
                usuario="root",
                senha="labinfo",
                banco="biblioteca",
            )
            repositorio = LivroRepository(conexao)
            resultado = repositorio.atualizar(livro)
        except Exception as erro:
            messagebox.showerror("Erro", f"Não foi possível atualizar o livro.\n{erro}")
            return

        ut.exibir_mensagem(resultado, "Livro atualizado com sucesso!", "Erro ao atualizar livro.")

        if resultado:
            self.livro_atual = livro
