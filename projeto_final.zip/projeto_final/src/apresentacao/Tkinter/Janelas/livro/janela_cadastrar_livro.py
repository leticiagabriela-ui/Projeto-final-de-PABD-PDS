import tkinter as tk
from tkinter import messagebox
from src.apresentacao.Tkinter.widgets import BotaoRedondo

from src.dados.conexao_singleton import ConexaoSingleton
from src.dados.livro_repository import LivroRepository
from src.dominio.livro import Livro
import src.apresentacao.Tkinter.utils as ut


class JanelaCadastroLivro:
    def __init__(self, janela):
        self.frame = tk.Frame(janela)
        self.frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)

        tk.Label(self.frame, text="Cadastro de Livro", font=("Arial", 14, "bold")).grid(
            row=0, column=0, columnspan=2, pady=(0, 15)
        )

        tk.Label(self.frame, text="Titulo:").grid(row=1, column=0, sticky='E', padx=5, pady=5)
        self.entrada_titulo = tk.Entry(self.frame)
        self.entrada_titulo.grid(row=1, column=1, sticky='W', padx=5, pady=5)

        tk.Label(self.frame, text="isbn:").grid(row=2, column=0, sticky='E', padx=5, pady=5)
        self.entrada_isbn = tk.Entry(self.frame)
        self.entrada_isbn.grid(row=2, column=1, sticky='W', padx=5, pady=5)

        tk.Label(self.frame, text="autor:").grid(row=3, column=0, sticky='E', padx=5, pady=5)
        self.entrada_autor = tk.Entry(self.frame)
        self.entrada_autor.grid(row=3, column=1, sticky='W', padx=5, pady=5)

        tk.Label(self.frame, text="ano_publicacao:").grid(row=4, column=0, sticky='E', padx=5, pady=5)
        self.entrada_ano_publicacao = tk.Entry(self.frame)
        self.entrada_ano_publicacao.grid(row=4, column=1, sticky='W', padx=5, pady=5)

        tk.Label(self.frame, text="Quantidade:").grid(row=5, column=0, sticky='E', padx=5, pady=5)
        self.entrada_quantidade = tk.Entry(self.frame)
        self.entrada_quantidade.grid(row=5, column=1, sticky='W', padx=5, pady=5)

        tk.Label(self.frame, text="genero:").grid(row=6, column=0, sticky='E', padx=5, pady=5)
        self.entrada_genero = tk.Entry(self.frame)
        self.entrada_genero.grid(row=6, column=1, sticky='W', padx=5, pady=5)

        tk.Label(self.frame, text="editora:").grid(row=7, column=0, sticky='E', padx=5, pady=5)
        self.entrada_editora = tk.Entry(self.frame)
        self.entrada_editora.grid(row=7, column=1, sticky='W', padx=5, pady=5)

        # Botão Salvar
        botao = BotaoRedondo(self.frame, text="Salvar", command=self.cadastrar_livro)
        botao.grid(row=8, column=0, padx=5, pady=10, columnspan=2)

        self.entrada_titulo.focus()

    def limpar_campos(self):
        self.entrada_titulo.delete(0, 'end')
        self.entrada_isbn.delete(0, 'end')
        self.entrada_autor.delete(0, 'end')
        self.entrada_ano_publicacao.delete(0, 'end')
        self.entrada_quantidade.delete(0, 'end')
        self.entrada_genero.delete(0, 'end')
        self.entrada_editora.delete(0, 'end')
        self.entrada_titulo.focus()

    def cadastrar_livro(self):
        titulo = self.entrada_titulo.get().strip()
        isbn = self.entrada_isbn.get().strip()
        autor = self.entrada_autor.get().strip()
        ano_publicacao = self.entrada_ano_publicacao.get().strip()
        quantidade = self.entrada_quantidade.get().strip()
        genero = self.entrada_genero.get().strip()
        editora = self.entrada_editora.get().strip()

        # Verifica se todos os campos foram preenchidos
        if not titulo or not isbn or not autor or not ano_publicacao or not quantidade or not genero or not editora:
            messagebox.showwarning("Atenção", "Preencha todos os campos!")
            return

        try:
            ano_publicacao = int(ano_publicacao)
        except ValueError:
            messagebox.showerror("Erro", "ano_publicacao deve ser número inteiro.")
            return

        try:
            quantidade = int(quantidade)
        except ValueError:
            messagebox.showerror("Erro", "quantidade deve ser número inteiro.")
            return

        # Cria objeto Livro (titulo e a chave primaria da tabela livro)
        livro = Livro(
            titulo=titulo,
            isbn=isbn,
            autor=autor,
            ano_publicacao=ano_publicacao,
            quantidade=quantidade,
            genero=genero,
            editora=editora,
        )

        resultado = False
        try:
            conexao = ConexaoSingleton.obter_conexao(
                tipo_banco="mysql",
                host="127.0.0.1",
                porta=3306,
                usuario="root",
                senha="labmari",
                banco="biblioteca",
            )
            repositorio = LivroRepository(conexao)
            repositorio.adicionar(livro)
            resultado = True
        except Exception as erro:
            messagebox.showerror("Erro", f"Não foi possível cadastrar o livro.\n{erro}")
            return

        # Mostra mensagem de sucesso ou erro
        ut.exibir_mensagem(resultado, "Livro cadastrado com sucesso!", "Erro ao cadastrar livro.")

        # Limpa campos se salvou com sucesso
        if resultado:
            self.limpar_campos()
