import tkinter as tk
from tkinter import messagebox

from src.apresentacao.Tkinter.widgets import BotaoRedondo

from src.config import SENHA_SISTEMA
from src.dados.conexao_singleton import ConexaoSingleton
from src.dados.funcionario_repository import FuncionarioRepository
from src.dominio.funcionario import Funcionario


class JanelaLogin:
    """Tela de login exibida antes do menu principal.

    O acesso é feito por matrícula do funcionário + a senha única do sistema
    (definida em `src/config.py`). O botão "Cadastrar Funcionário" abre um
    formulário próprio para criar uma nova matrícula.
    """

    def __init__(self, janela, ao_autenticar):
        self.ao_autenticar = ao_autenticar
        self.senha_visivel = False
        self.cadastro_visivel = False

        self.frame = tk.Frame(janela)
        self.frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)

        tk.Label(
            self.frame, text="Sistema de Biblioteca", font=("Georgia", 18, "bold italic")
        ).grid(row=0, column=0, columnspan=3, pady=(0, 20))

        tk.Label(self.frame, text="Entrar", font=("Arial", 14, "bold")).grid(
            row=1, column=0, columnspan=3, pady=(0, 15)
        )

        tk.Label(self.frame, text="Matrícula:").grid(row=2, column=0, sticky="E", padx=5, pady=5)
        self.entrada_matricula = tk.Entry(self.frame)
        self.entrada_matricula.grid(row=2, column=1, sticky="W", padx=5, pady=5)

        tk.Label(self.frame, text="Senha do sistema:").grid(row=3, column=0, sticky="E", padx=5, pady=5)
        self.entrada_senha = tk.Entry(self.frame, show="*")
        self.entrada_senha.grid(row=3, column=1, sticky="W", padx=5, pady=5)
        self.entrada_senha.bind("<Return>", lambda evento: self.entrar())

        # Botão para mostrar/ocultar a senha, bem ao lado do campo de senha
        self.botao_ver_senha = BotaoRedondo(
            self.frame, text="Mostrar", height=28, command=self.alternar_senha
        )
        self.botao_ver_senha.grid(row=3, column=2, sticky="W", padx=(5, 0))

        self.botao_entrar = BotaoRedondo(self.frame, text="Entrar", command=self.entrar)
        self.botao_entrar.grid(row=4, column=0, columnspan=3, pady=(10, 5))

        self.botao_cadastrar_funcionario = BotaoRedondo(
            self.frame, text="Cadastrar Funcionário", command=self.alternar_cadastro
        )
        self.botao_cadastrar_funcionario.grid(row=5, column=0, columnspan=3, pady=(0, 5))

        # --- Área de cadastro: exibida/ocultada pelo botão "Cadastrar Funcionário" ---
        self.frame_cadastro = tk.LabelFrame(self.frame, text="Cadastro de novo funcionário")

        tk.Label(self.frame_cadastro, text="Matrícula:").grid(row=0, column=0, sticky="E", padx=5, pady=5)
        self.entrada_cadastro_matricula = tk.Entry(self.frame_cadastro)
        self.entrada_cadastro_matricula.grid(row=0, column=1, sticky="W", padx=5, pady=5)

        tk.Label(self.frame_cadastro, text="Nome:").grid(row=1, column=0, sticky="E", padx=5, pady=5)
        self.entrada_nome = tk.Entry(self.frame_cadastro)
        self.entrada_nome.grid(row=1, column=1, sticky="W", padx=5, pady=5)

        tk.Label(self.frame_cadastro, text="Email:").grid(row=2, column=0, sticky="E", padx=5, pady=5)
        self.entrada_email = tk.Entry(self.frame_cadastro)
        self.entrada_email.grid(row=2, column=1, sticky="W", padx=5, pady=5)
        self.entrada_email.bind("<Return>", lambda evento: self.cadastrar())

        BotaoRedondo(self.frame_cadastro, text="Salvar Cadastro", command=self.cadastrar).grid(
            row=3, column=0, columnspan=2, pady=(5, 5)
        )

        self.entrada_matricula.focus()

    def _obter_repositorio(self) -> FuncionarioRepository:
        conexao = ConexaoSingleton.obter_conexao(
            tipo_banco="mysql",
            host="127.0.0.1",
            porta=3306,
            usuario="root",
            senha="labmari",
            banco="biblioteca",
        )
        return FuncionarioRepository(conexao)

    def alternar_senha(self):
        self.senha_visivel = not self.senha_visivel
        self.entrada_senha.configure(show="" if self.senha_visivel else "*")
        self.botao_ver_senha.configure(text="Ocultar" if self.senha_visivel else "Mostrar")

    def alternar_cadastro(self):
        self.cadastro_visivel = not self.cadastro_visivel
        if self.cadastro_visivel:
            self.entrada_cadastro_matricula.delete(0, "end")
            self.entrada_cadastro_matricula.insert(0, self.entrada_matricula.get().strip())
            self.frame_cadastro.grid(row=6, column=0, columnspan=3, pady=(10, 0), sticky="EW")
            self.botao_cadastrar_funcionario.configure(text="Cancelar Cadastro")
            self.entrada_cadastro_matricula.focus()
        else:
            self.frame_cadastro.grid_forget()
            self.botao_cadastrar_funcionario.configure(text="Cadastrar Funcionário")

    def entrar(self):
        matricula = self.entrada_matricula.get().strip()
        senha = self.entrada_senha.get().strip()

        if not matricula or not senha:
            messagebox.showwarning("Atenção", "Preencha matrícula e senha.")
            return

        if senha != SENHA_SISTEMA:
            messagebox.showerror("Erro", "Senha incorreta.")
            return

        try:
            repositorio = self._obter_repositorio()
            funcionario = repositorio.buscar_por_matricula(matricula)
        except Exception as erro:
            messagebox.showerror("Erro", f"Não foi possível efetuar o login.\n{erro}")
            return

        if funcionario is not None:
            self.ao_autenticar(funcionario)
            return

        messagebox.showwarning(
            "Atenção", "Matrícula não encontrada. Use o botão 'Cadastrar Funcionário' abaixo."
        )
        if not self.cadastro_visivel:
            self.alternar_cadastro()

    def cadastrar(self):
        matricula = self.entrada_cadastro_matricula.get().strip()
        nome = self.entrada_nome.get().strip()
        email = self.entrada_email.get().strip()

        if not matricula or not nome:
            messagebox.showwarning("Atenção", "Preencha ao menos a matrícula e o nome.")
            return

        funcionario = Funcionario(nome=nome, matricula=matricula, email=email)

        try:
            repositorio = self._obter_repositorio()
            if repositorio.buscar_por_matricula(matricula) is not None:
                messagebox.showwarning("Atenção", "Já existe um funcionário com essa matrícula.")
                return
            repositorio.adicionar(funcionario)
        except Exception as erro:
            messagebox.showerror("Erro", f"Não foi possível cadastrar o funcionário.\n{erro}")
            return

        messagebox.showinfo("Sucesso", "Funcionário cadastrado com sucesso!")
        self.ao_autenticar(funcionario)
