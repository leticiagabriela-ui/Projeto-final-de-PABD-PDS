import tkinter as tk
from tkinter import messagebox, ttk
from src.apresentacao.Tkinter.widgets import BotaoRedondo

from src.dados.conexao_singleton import ConexaoSingleton
from src.dados.emprestimo_repository import EmprestimoRepository
from src.dominio.emprestimo import Emprestimo, STATUS_EMPRESTADO, STATUS_VALIDOS
import src.apresentacao.Tkinter.utils as ut


class JanelaCadastroEmprestimo:
    def __init__(self, janela):
        self.frame = tk.Frame(janela)
        self.frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)

        tk.Label(self.frame, text="Cadastro de Empréstimo", font=("Arial", 14, "bold")).grid(
            row=0, column=0, columnspan=2, pady=(0, 15)
        )

        tk.Label(self.frame, text="Matrícula do Aluno:").grid(row=1, column=0, sticky='E', padx=5, pady=5)
        self.entrada_matricula_aluno = tk.Entry(self.frame)
        self.entrada_matricula_aluno.grid(row=1, column=1, sticky='W', padx=5, pady=5)

        tk.Label(self.frame, text="Título do Livro:").grid(row=2, column=0, sticky='E', padx=5, pady=5)
        self.entrada_titulo_livro = tk.Entry(self.frame)
        self.entrada_titulo_livro.grid(row=2, column=1, sticky='W', padx=5, pady=5)

        tk.Label(self.frame, text="Data do Empréstimo (aaaa-mm-dd):").grid(row=3, column=0, sticky='E', padx=5, pady=5)
        self.entrada_data_emprestimo = tk.Entry(self.frame)
        self.entrada_data_emprestimo.grid(row=3, column=1, sticky='W', padx=5, pady=5)

        tk.Label(self.frame, text="Data de Devolução (aaaa-mm-dd):").grid(row=4, column=0, sticky='E', padx=5, pady=5)
        self.entrada_data_devolucao = tk.Entry(self.frame)
        self.entrada_data_devolucao.grid(row=4, column=1, sticky='W', padx=5, pady=5)

        tk.Label(self.frame, text="Status:").grid(row=5, column=0, sticky='E', padx=5, pady=5)
        self.combo_status = ttk.Combobox(
            self.frame, values=list(STATUS_VALIDOS), state="readonly"
        )
        self.combo_status.set(STATUS_EMPRESTADO)
        self.combo_status.grid(row=5, column=1, sticky='W', padx=5, pady=5)

        # Botão Salvar
        botao = BotaoRedondo(self.frame, text="Salvar", command=self.cadastrar_emprestimo)
        botao.grid(row=6, column=0, padx=5, pady=10, columnspan=2)

        self.entrada_matricula_aluno.focus()

    def limpar_campos(self):
        self.entrada_matricula_aluno.delete(0, 'end')
        self.entrada_titulo_livro.delete(0, 'end')
        self.entrada_data_emprestimo.delete(0, 'end')
        self.entrada_data_devolucao.delete(0, 'end')
        self.combo_status.set(STATUS_EMPRESTADO)
        self.entrada_matricula_aluno.focus()

    def cadastrar_emprestimo(self):
        matricula_aluno = self.entrada_matricula_aluno.get().strip()
        titulo_livro = self.entrada_titulo_livro.get().strip()
        data_emprestimo = self.entrada_data_emprestimo.get().strip()
        data_devolucao = self.entrada_data_devolucao.get().strip()
        status = self.combo_status.get().strip()

        # Verifica se todos os campos foram preenchidos
        if not matricula_aluno or not titulo_livro or not data_emprestimo or not data_devolucao or not status:
            messagebox.showwarning("Atenção", "Preencha todos os campos!")
            return

        # Cria objeto Emprestimo (id e gerado automaticamente pelo banco)
        emprestimo = Emprestimo(
            matricula_aluno=matricula_aluno,
            titulo=titulo_livro,
            data_emprestimo=data_emprestimo,
            data_devolucao=data_devolucao,
            status=status,
        )

        resultado = False
        try:
            conexao = ConexaoSingleton.obter_conexao(
                tipo_banco="mysql",
                host="127.0.0.1",
                porta=3306,
                usuario="root",
                senha="labmari",
                banco="biblioteca",
            )
            repositorio = EmprestimoRepository(conexao)
            repositorio.adicionar(emprestimo)
            resultado = True
        except Exception as erro:
            messagebox.showerror("Erro", f"Não foi possível cadastrar o empréstimo.\n{erro}")
            return

        # Mostra mensagem de sucesso ou erro
        ut.exibir_mensagem(resultado, "Empréstimo cadastrado com sucesso!", "Erro ao cadastrar empréstimo.")

        # Limpa campos se salvou com sucesso
        if resultado:
            self.limpar_campos()
