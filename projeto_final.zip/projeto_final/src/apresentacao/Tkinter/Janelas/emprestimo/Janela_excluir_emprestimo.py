import tkinter as tk
from tkinter import messagebox
from src.apresentacao.Tkinter.widgets import BotaoRedondo

from src.dados.conexao_singleton import ConexaoSingleton
from src.dados.emprestimo_repository import EmprestimoRepository
import src.apresentacao.Tkinter.utils as ut


class JanelaExcluirEmprestimo:
    def __init__(self, janela):
        self.frame = tk.Frame(janela)
        self.frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)

        tk.Label(self.frame, text="Excluir Empréstimo", font=("Arial", 14, "bold")).grid(
            row=0, column=0, columnspan=2, pady=(0, 15)
        )

        tk.Label(self.frame, text="ID do Empréstimo:").grid(row=1, column=0, sticky='E', padx=5, pady=5)
        self.entrada_id = tk.Entry(self.frame)
        self.entrada_id.grid(row=1, column=1, sticky='W', padx=5, pady=5)

        BotaoRedondo(self.frame, text="Excluir", command=self.excluir_emprestimo).grid(
            row=2, column=0, columnspan=2, padx=5, pady=10
        )

        self.entrada_id.focus()

    def excluir_emprestimo(self):
        id_texto = self.entrada_id.get().strip()
        if not id_texto:
            messagebox.showwarning("Atenção", "Informe o ID do empréstimo.")
            return
        try:
            id_emprestimo = int(id_texto)
        except ValueError:
            messagebox.showerror("Erro", "ID deve ser um número inteiro.")
            return

        confirmar = messagebox.askyesno(
            "Confirmar", f"Tem certeza que deseja excluir o empréstimo com ID {id_emprestimo}?"
        )
        if not confirmar:
            return

        resultado = False
        try:
            conexao = ConexaoSingleton.obter_conexao(
                tipo_banco="mysql",
                host="127.0.0.1",
                porta=3306,
                usuario="root",
                senha="labmari",
                banco="biblioteca",
            )
            repositorio = EmprestimoRepository(conexao)
            resultado = repositorio.remover(id_emprestimo)
        except Exception as erro:
            messagebox.showerror("Erro", f"Não foi possível excluir o empréstimo.\n{erro}")
            return

        ut.exibir_mensagem(resultado, "Empréstimo excluído com sucesso!", "Empréstimo não encontrado.")

        if resultado:
            self.entrada_id.delete(0, 'end')
            self.entrada_id.focus()
