import tkinter as tk
from tkinter import messagebox, ttk
from src.apresentacao.Tkinter.widgets import BotaoRedondo

from src.dados.conexao_singleton import ConexaoSingleton
from src.dados.emprestimo_repository import EmprestimoRepository
from src.dominio.emprestimo import Emprestimo, STATUS_EMPRESTADO, STATUS_VALIDOS
import src.apresentacao.Tkinter.utils as ut


class JanelaAtualizarEmprestimo:
    def __init__(self, janela):
        self.emprestimo_atual = None

        self.frame = tk.Frame(janela)
        self.frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)

        tk.Label(self.frame, text="Atualizar Empréstimo", font=("Arial", 14, "bold")).grid(
            row=0, column=0, columnspan=3, pady=(0, 15)
        )

        tk.Label(self.frame, text="ID do Empréstimo:").grid(row=1, column=0, sticky='E', padx=5, pady=5)
        self.entrada_id = tk.Entry(self.frame)
        self.entrada_id.grid(row=1, column=1, sticky='W', padx=5, pady=5)
        BotaoRedondo(self.frame, text="Buscar", command=self.buscar_emprestimo).grid(row=1, column=2, padx=5, pady=5)

        tk.Label(self.frame, text="Matrícula do Aluno:").grid(row=2, column=0, sticky='E', padx=5, pady=5)
        self.entrada_matricula_aluno = tk.Entry(self.frame)
        self.entrada_matricula_aluno.grid(row=2, column=1, sticky='W', padx=5, pady=5)

        tk.Label(self.frame, text="Título do Livro:").grid(row=3, column=0, sticky='E', padx=5, pady=5)
        self.entrada_titulo_livro = tk.Entry(self.frame)
        self.entrada_titulo_livro.grid(row=3, column=1, sticky='W', padx=5, pady=5)

        tk.Label(self.frame, text="Data do Empréstimo (aaaa-mm-dd):").grid(row=4, column=0, sticky='E', padx=5, pady=5)
        self.entrada_data_emprestimo = tk.Entry(self.frame)
        self.entrada_data_emprestimo.grid(row=4, column=1, sticky='W', padx=5, pady=5)

        tk.Label(self.frame, text="Data de Devolução (aaaa-mm-dd):").grid(row=5, column=0, sticky='E', padx=5, pady=5)
        self.entrada_data_devolucao = tk.Entry(self.frame)
        self.entrada_data_devolucao.grid(row=5, column=1, sticky='W', padx=5, pady=5)

        tk.Label(self.frame, text="Status:").grid(row=6, column=0, sticky='E', padx=5, pady=5)
        self.combo_status = ttk.Combobox(
            self.frame, values=list(STATUS_VALIDOS), state="readonly"
        )
        self.combo_status.set(STATUS_EMPRESTADO)
        self.combo_status.grid(row=6, column=1, sticky='W', padx=5, pady=5)

        BotaoRedondo(self.frame, text="Salvar Alterações", command=self.atualizar_emprestimo).grid(
            row=7, column=0, columnspan=3, padx=5, pady=10
        )

        self.entrada_id.focus()

    def limpar_campos_dados(self):
        self.entrada_matricula_aluno.delete(0, 'end')
        self.entrada_titulo_livro.delete(0, 'end')
        self.entrada_data_emprestimo.delete(0, 'end')
        self.entrada_data_devolucao.delete(0, 'end')

    def preencher_campos(self, emprestimo):
        self.limpar_campos_dados()
        self.entrada_matricula_aluno.insert(0, emprestimo.matricula_aluno)
        self.entrada_titulo_livro.insert(0, emprestimo.titulo)
        self.entrada_data_emprestimo.insert(0, emprestimo.data_emprestimo)
        self.entrada_data_devolucao.insert(0, emprestimo.data_devolucao)
        self.combo_status.set(emprestimo.status)

    def buscar_emprestimo(self):
        id_texto = self.entrada_id.get().strip()
        if not id_texto:
            messagebox.showwarning("Atenção", "Informe o ID do empréstimo.")
            return
        try:
            id_emprestimo = int(id_texto)
        except ValueError:
            messagebox.showerror("Erro", "ID deve ser um número inteiro.")
            return

        try:
            conexao = ConexaoSingleton.obter_conexao(
                tipo_banco="mysql",
                host="127.0.0.1",
                porta=3306,
                usuario="root",
                senha="labmari",
                banco="biblioteca",
            )
            repositorio = EmprestimoRepository(conexao)
            emprestimo = repositorio.buscar_por_id(id_emprestimo)
        except Exception as erro:
            messagebox.showerror("Erro", f"Não foi possível buscar o empréstimo.\n{erro}")
            return

        if emprestimo is None:
            messagebox.showwarning("Atenção", "Empréstimo não encontrado.")
            self.emprestimo_atual = None
            self.limpar_campos_dados()
            return

        self.emprestimo_atual = emprestimo
        self.preencher_campos(emprestimo)

    def atualizar_emprestimo(self):
        if self.emprestimo_atual is None:
            messagebox.showwarning("Atenção", "Busque um empréstimo pelo ID antes de salvar.")
            return

        matricula_aluno = self.entrada_matricula_aluno.get().strip()
        titulo_livro = self.entrada_titulo_livro.get().strip()
        data_emprestimo = self.entrada_data_emprestimo.get().strip()
        data_devolucao = self.entrada_data_devolucao.get().strip()
        status = self.combo_status.get().strip()

        if not matricula_aluno or not titulo_livro or not data_emprestimo or not data_devolucao or not status:
            messagebox.showwarning("Atenção", "Preencha todos os campos!")
            return

        emprestimo = Emprestimo(
            id=self.emprestimo_atual.id,
            matricula_aluno=matricula_aluno,
            titulo=titulo_livro,
            data_emprestimo=data_emprestimo,
            data_devolucao=data_devolucao,
            status=status,
        )

        resultado = False
        try:
            conexao = ConexaoSingleton.obter_conexao(
                tipo_banco="mysql",
                host="127.0.0.1",
                porta=3306,
                usuario="root",
                senha="labinfo",
                banco="biblioteca",
            )
            repositorio = EmprestimoRepository(conexao)
            resultado = repositorio.atualizar(emprestimo)
        except Exception as erro:
            messagebox.showerror("Erro", f"Não foi possível atualizar o empréstimo.\n{erro}")
            return

        ut.exibir_mensagem(resultado, "Empréstimo atualizado com sucesso!", "Erro ao atualizar empréstimo.")

        if resultado:
            self.emprestimo_atual = emprestimo
