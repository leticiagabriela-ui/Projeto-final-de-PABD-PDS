import tkinter as tk
from tkinter import ttk, messagebox
from src.apresentacao.Tkinter.widgets import BotaoRedondo

from src.dados.conexao_singleton import ConexaoSingleton
from src.dados.emprestimo_repository import EmprestimoRepository
from src.dominio.emprestimo import Emprestimo, STATUS_VALIDOS


class JanelaConsultarEmprestimo:
    def __init__(self, janela):
        self.emprestimo_atual = None
        self.emprestimos_encontrados = {}

        self.frame = tk.Frame(janela)
        self.frame.pack(fill="both", expand=True, padx=20, pady=20)

        tk.Label(self.frame, text="Consultar Empréstimo", font=("Arial", 14, "bold")).pack(pady=(0, 15))

        # --- Campo de busca (por matrícula do aluno) ---
        frame_busca = tk.Frame(self.frame)
        frame_busca.pack(fill="x", pady=(0, 10))

        tk.Label(frame_busca, text="Matrícula do Aluno:").pack(side="left")

        self.termo_busca = tk.StringVar()
        entrada_busca = tk.Entry(frame_busca, textvariable=self.termo_busca)
        entrada_busca.pack(side="left", fill="x", expand=True, padx=(5, 5))
        entrada_busca.bind("<Return>", lambda evento: self.buscar_emprestimos())

        BotaoRedondo(frame_busca, text="Buscar", command=self.buscar_emprestimos).pack(side="left")
        BotaoRedondo(frame_busca, text="Limpar", command=self.limpar_busca).pack(side="left", padx=(5, 0))

        # --- Lista de resultado da busca (pode haver mais de um empréstimo por aluno) ---
        colunas = ("id", "matricula_aluno", "titulo", "data_emprestimo", "data_devolucao", "status")
        self.tabela = ttk.Treeview(self.frame, columns=colunas, show="headings", height=6)

        titulos = {
            "id": "ID",
            "matricula_aluno": "Matrícula do Aluno",
            "titulo": "Título do Livro",
            "data_emprestimo": "Data Empréstimo",
            "data_devolucao": "Data Devolução",
            "status": "Status",
        }
        for coluna in colunas:
            self.tabela.heading(coluna, text=titulos[coluna])
            self.tabela.column(coluna, width=120, anchor="center")

        self.tabela.pack(fill="x", pady=(0, 5))
        self.tabela.bind("<<TreeviewSelect>>", self.selecionar_emprestimo)

        tk.Label(
            self.frame, text="Selecione um empréstimo na lista acima para editar.", fg="#555"
        ).pack(anchor="w", pady=(0, 15))

        # --- Área de edição (habilitada após selecionar um empréstimo) ---
        frame_edicao = tk.LabelFrame(self.frame, text="Atualizar dados do empréstimo selecionado")
        frame_edicao.pack(fill="x", padx=5, pady=5)

        tk.Label(frame_edicao, text="Matrícula do Aluno:").grid(row=0, column=0, sticky="E", padx=5, pady=5)
        self.entrada_matricula_aluno = tk.Entry(frame_edicao, state="disabled")
        self.entrada_matricula_aluno.grid(row=0, column=1, sticky="EW", padx=5, pady=5)

        tk.Label(frame_edicao, text="Título do Livro:").grid(row=1, column=0, sticky="E", padx=5, pady=5)
        self.entrada_titulo_livro = tk.Entry(frame_edicao, state="disabled")
        self.entrada_titulo_livro.grid(row=1, column=1, sticky="EW", padx=5, pady=5)

        tk.Label(frame_edicao, text="Data do Empréstimo (aaaa-mm-dd):").grid(row=2, column=0, sticky="E", padx=5, pady=5)
        self.entrada_data_emprestimo = tk.Entry(frame_edicao, state="disabled")
        self.entrada_data_emprestimo.grid(row=2, column=1, sticky="EW", padx=5, pady=5)

        tk.Label(frame_edicao, text="Data de Devolução (aaaa-mm-dd):").grid(row=3, column=0, sticky="E", padx=5, pady=5)
        self.entrada_data_devolucao = tk.Entry(frame_edicao, state="disabled")
        self.entrada_data_devolucao.grid(row=3, column=1, sticky="EW", padx=5, pady=5)

        tk.Label(frame_edicao, text="Status:").grid(row=4, column=0, sticky="E", padx=5, pady=5)
        self.combo_status = ttk.Combobox(
            frame_edicao, values=list(STATUS_VALIDOS), state="disabled"
        )
        self.combo_status.grid(row=4, column=1, sticky="EW", padx=5, pady=5)

        frame_edicao.columnconfigure(1, weight=1)

        self.botao_salvar = BotaoRedondo(
            frame_edicao, text="Salvar Alterações", command=self.atualizar_emprestimo, state="disabled"
        )
        self.botao_salvar.grid(row=5, column=0, columnspan=2, pady=10)

        entrada_busca.focus()

    def limpar_busca(self):
        self.termo_busca.set("")
        for linha in self.tabela.get_children():
            self.tabela.delete(linha)
        self.emprestimos_encontrados = {}
        self.emprestimo_atual = None
        self._definir_campos_edicao(habilitado=False)

    def _preencher_entrada(self, entrada, valor, habilitado):
        estado = "normal" if habilitado else "disabled"
        entrada.configure(state="normal")
        entrada.delete(0, "end")
        if valor is not None:
            entrada.insert(0, str(valor))
        entrada.configure(state=estado)

    def _definir_campos_edicao(self, habilitado, emprestimo=None):
        self._preencher_entrada(
            self.entrada_matricula_aluno, emprestimo.matricula_aluno if emprestimo else None, habilitado
        )
        self._preencher_entrada(
            self.entrada_titulo_livro, emprestimo.titulo if emprestimo else None, habilitado
        )
        self._preencher_entrada(
            self.entrada_data_emprestimo, emprestimo.data_emprestimo if emprestimo else None, habilitado
        )
        self._preencher_entrada(
            self.entrada_data_devolucao, emprestimo.data_devolucao if emprestimo else None, habilitado
        )

        self.combo_status.configure(state="readonly" if habilitado else "disabled")
        self.combo_status.set(emprestimo.status if (habilitado and emprestimo) else "")

        self.botao_salvar.configure(state="normal" if habilitado else "disabled")

    def buscar_emprestimos(self):
        for linha in self.tabela.get_children():
            self.tabela.delete(linha)
        self.emprestimos_encontrados = {}
        self.emprestimo_atual = None
        self._definir_campos_edicao(habilitado=False)

        matricula = self.termo_busca.get().strip()
        if not matricula:
            messagebox.showwarning("Atenção", "Informe a matrícula do aluno.")
            return

        try:
            conexao = ConexaoSingleton.obter_conexao(
                tipo_banco="mysql",
                host="127.0.0.1",
                porta=3306,
                usuario="root",
                senha="labmari",
                banco="biblioteca",
            )
            repositorio = EmprestimoRepository(conexao)
            emprestimos = repositorio.buscar_por_matricula_aluno(matricula)
        except Exception as erro:
            messagebox.showerror("Erro", f"Não foi possível consultar os empréstimos.\n{erro}")
            return

        if not emprestimos:
            self.tabela.insert("", "end", values=("Nenhum empréstimo encontrado", "", "", "", "", ""))
            return

        for emprestimo in emprestimos:
            iid = str(emprestimo.id)
            self.emprestimos_encontrados[iid] = emprestimo
            self.tabela.insert("", "end", iid=iid, values=(
                emprestimo.id, emprestimo.matricula_aluno, emprestimo.titulo,
                emprestimo.data_emprestimo, emprestimo.data_devolucao, emprestimo.status,
            ))

    def selecionar_emprestimo(self, evento=None):
        selecionados = self.tabela.selection()
        if not selecionados:
            return

        emprestimo = self.emprestimos_encontrados.get(selecionados[0])
        if emprestimo is None:
            self.emprestimo_atual = None
            self._definir_campos_edicao(habilitado=False)
            return

        self.emprestimo_atual = emprestimo
        self._definir_campos_edicao(habilitado=True, emprestimo=emprestimo)

    def atualizar_emprestimo(self):
        if self.emprestimo_atual is None:
            messagebox.showwarning("Atenção", "Selecione um empréstimo na lista antes de salvar.")
            return

        matricula_aluno = self.entrada_matricula_aluno.get().strip()
        titulo_livro = self.entrada_titulo_livro.get().strip()
        data_emprestimo = self.entrada_data_emprestimo.get().strip()
        data_devolucao = self.entrada_data_devolucao.get().strip()
        status = self.combo_status.get().strip()

        if not matricula_aluno or not titulo_livro or not data_emprestimo or not data_devolucao or not status:
            messagebox.showwarning("Atenção", "Preencha todos os campos!")
            return

        emprestimo_atualizado = Emprestimo(
            id=self.emprestimo_atual.id,
            matricula_aluno=matricula_aluno,
            titulo=titulo_livro,
            data_emprestimo=data_emprestimo,
            data_devolucao=data_devolucao,
            status=status,
        )

        try:
            conexao = ConexaoSingleton.obter_conexao(
                tipo_banco="mysql",
                host="127.0.0.1",
                porta=3306,
                usuario="root",
                senha="labinfo",
                banco="biblioteca",
            )
            repositorio = EmprestimoRepository(conexao)
            resultado = repositorio.atualizar(emprestimo_atualizado)
        except Exception as erro:
            messagebox.showerror("Erro", f"Não foi possível atualizar o empréstimo.\n{erro}")
            return

        if resultado:
            messagebox.showinfo("Sucesso", "Empréstimo atualizado com sucesso!")
            self.emprestimo_atual = emprestimo_atualizado
            self.buscar_emprestimos()
        else:
            messagebox.showerror("Erro", "Não foi possível atualizar o empréstimo.")
