import tkinter as tk
from tkinter import ttk, messagebox
from src.apresentacao.Tkinter.widgets import BotaoRedondo

from src.dados.conexao_singleton import ConexaoSingleton
from src.dados.aluno_repository import AlunoRepository
from src.dominio.aluno import Aluno


class JanelaConsultarAluno:
    def __init__(self, janela):
        self.aluno_atual = None

        self.frame = tk.Frame(janela)
        self.frame.pack(fill="both", expand=True, padx=20, pady=20)

        tk.Label(self.frame, text="Consultar Aluno", font=("Arial", 14, "bold")).pack(pady=(0, 15))

        # --- Campo de busca (somente matrícula) ---
        frame_busca = tk.Frame(self.frame)
        frame_busca.pack(fill="x", pady=(0, 10))

        tk.Label(frame_busca, text="Matrícula:").pack(side="left")

        self.termo_busca = tk.StringVar()
        entrada_busca = tk.Entry(frame_busca, textvariable=self.termo_busca)
        entrada_busca.pack(side="left", fill="x", expand=True, padx=(5, 5))
        entrada_busca.bind("<Return>", lambda evento: self.buscar_aluno())

        BotaoRedondo(frame_busca, text="Buscar", command=self.buscar_aluno).pack(side="left")
        BotaoRedondo(frame_busca, text="Limpar", command=self.limpar_busca).pack(side="left", padx=(5, 0))

        # --- Lista de resultado da busca ---
        colunas = ("matricula", "nome", "email")
        self.tabela = ttk.Treeview(self.frame, columns=colunas, show="headings", height=5)

        titulos = {
            "matricula": "Matrícula",
            "nome": "Nome",
            "email": "Email",
        }
        for coluna in colunas:
            self.tabela.heading(coluna, text=titulos[coluna])
            self.tabela.column(coluna, width=120, anchor="center")

        self.tabela.pack(fill="x", pady=(0, 20))

        # --- Área de edição (habilitada após encontrar o aluno) ---
        frame_edicao = tk.LabelFrame(self.frame, text="Atualizar dados do aluno encontrado")
        frame_edicao.pack(fill="x", padx=5, pady=5)

        tk.Label(frame_edicao, text="Nome:").grid(row=0, column=0, sticky="E", padx=5, pady=5)
        self.entrada_nome = tk.Entry(frame_edicao, state="disabled")
        self.entrada_nome.grid(row=0, column=1, sticky="EW", padx=5, pady=5)

        tk.Label(frame_edicao, text="Email:").grid(row=1, column=0, sticky="E", padx=5, pady=5)
        self.entrada_email = tk.Entry(frame_edicao, state="disabled")
        self.entrada_email.grid(row=1, column=1, sticky="EW", padx=5, pady=5)

        frame_edicao.columnconfigure(1, weight=1)

        self.botao_salvar = BotaoRedondo(
            frame_edicao, text="Salvar Alterações", command=self.atualizar_aluno, state="disabled"
        )
        self.botao_salvar.grid(row=2, column=0, columnspan=2, pady=10)

        entrada_busca.focus()

    def limpar_busca(self):
        self.termo_busca.set("")
        for linha in self.tabela.get_children():
            self.tabela.delete(linha)
        self.aluno_atual = None
        self._definir_campos_edicao(habilitado=False)

    def _definir_campos_edicao(self, habilitado, aluno=None):
        estado = "normal" if habilitado else "disabled"

        self.entrada_nome.configure(state="normal")
        self.entrada_nome.delete(0, "end")
        if aluno:
            self.entrada_nome.insert(0, aluno.nome)
        self.entrada_nome.configure(state=estado)

        self.entrada_email.configure(state="normal")
        self.entrada_email.delete(0, "end")
        if aluno:
            self.entrada_email.insert(0, aluno.email)
        self.entrada_email.configure(state=estado)

        self.botao_salvar.configure(state=estado)

    def buscar_aluno(self):
        for linha in self.tabela.get_children():
            self.tabela.delete(linha)

        matricula = self.termo_busca.get().strip()
        if not matricula:
            messagebox.showwarning("Atenção", "Informe a matrícula do aluno.")
            return

        try:
            conexao = ConexaoSingleton.obter_conexao(
                tipo_banco="mysql",
                host="127.0.0.1",
                porta=3306,
                usuario="root",
                senha="labmari",
                banco="biblioteca",
            )
            repositorio = AlunoRepository(conexao)
            aluno = repositorio.buscar_por_matricula(matricula)
        except Exception as erro:
            messagebox.showerror("Erro", f"Não foi possível consultar o aluno.\n{erro}")
            return

        if aluno is None:
            self.tabela.insert("", "end", values=("Nenhum aluno encontrado", "", ""))
            self.aluno_atual = None
            self._definir_campos_edicao(habilitado=False)
            return

        self.tabela.insert("", "end", values=(aluno.matricula, aluno.nome, aluno.email))
        self.aluno_atual = aluno
        self._definir_campos_edicao(habilitado=True, aluno=aluno)

    def atualizar_aluno(self):
        if self.aluno_atual is None:
            messagebox.showwarning("Atenção", "Busque um aluno pela matrícula antes de salvar.")
            return

        nome = self.entrada_nome.get().strip()
        email = self.entrada_email.get().strip()

        if not nome or not email:
            messagebox.showwarning("Atenção", "Preencha todos os campos!")
            return

        aluno_atualizado = Aluno(matricula=self.aluno_atual.matricula, nome=nome, email=email)

        try:
            conexao = ConexaoSingleton.obter_conexao(
                tipo_banco="mysql",
                host="127.0.0.1",
                porta=3306,
                usuario="root",
                senha="labinfo",
                banco="biblioteca",
            )
            repositorio = AlunoRepository(conexao)
            resultado = repositorio.atualizar(aluno_atualizado)
        except Exception as erro:
            messagebox.showerror("Erro", f"Não foi possível atualizar o aluno.\n{erro}")
            return

        if resultado:
            messagebox.showinfo("Sucesso", "Aluno atualizado com sucesso!")
            self.aluno_atual = aluno_atualizado
            self.buscar_aluno()
        else:
            messagebox.showerror("Erro", "Não foi possível atualizar o aluno.")
