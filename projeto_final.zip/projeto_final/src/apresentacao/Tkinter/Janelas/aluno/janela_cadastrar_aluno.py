import tkinter as tk
from tkinter import messagebox
from src.apresentacao.Tkinter.widgets import BotaoRedondo

from src.dados.conexao_singleton import ConexaoSingleton
from src.dados.aluno_repository import AlunoRepository
from src.dominio.aluno import Aluno
import src.apresentacao.Tkinter.utils as ut


class JanelaCadastroAluno:
    def __init__(self, janela):
        self.frame = tk.Frame(janela)
        self.frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)

        tk.Label(self.frame, text="Cadastro de Aluno", font=("Arial", 14, "bold")).grid(
            row=0, column=0, columnspan=2, pady=(0, 15)
        )

        tk.Label(self.frame, text="Nome:").grid(row=1, column=0, sticky='E', padx=5, pady=5)
        self.entrada_nome = tk.Entry(self.frame)
        self.entrada_nome.grid(row=1, column=1, sticky='W', padx=5, pady=5)

        tk.Label(self.frame, text="Matrícula:").grid(row=2, column=0, sticky='E', padx=5, pady=5)
        self.entrada_matricula = tk.Entry(self.frame)
        self.entrada_matricula.grid(row=2, column=1, sticky='W', padx=5, pady=5)

        tk.Label(self.frame, text="Email:").grid(row=3, column=0, sticky='E', padx=5, pady=5)
        self.entrada_email = tk.Entry(self.frame)
        self.entrada_email.grid(row=3, column=1, sticky='W', padx=5, pady=5)

        # Botão Salvar
        botao = BotaoRedondo(self.frame, text="Salvar", command=self.cadastrar_aluno)
        botao.grid(row=4, column=0, padx=5, pady=10, columnspan=2)

        self.entrada_nome.focus()

    def limpar_campos(self):
        self.entrada_nome.delete(0, 'end')
        self.entrada_matricula.delete(0, 'end')
        self.entrada_email.delete(0, 'end')
        self.entrada_nome.focus()

    def cadastrar_aluno(self):
        nome = self.entrada_nome.get().strip()
        matricula = self.entrada_matricula.get().strip()
        email = self.entrada_email.get().strip()

        # Verifica se todos os campos foram preenchidos
        if not nome or not matricula or not email:
            messagebox.showwarning("Atenção", "Preencha todos os campos!")
            return

        # Cria objeto Aluno (matricula e a chave primaria da tabela aluno)
        aluno = Aluno(nome=nome, matricula=matricula, email=email)

        resultado = False
        try:
            conexao = ConexaoSingleton.obter_conexao(
                tipo_banco="mysql",
                host="127.0.0.1",
                porta=3306,
                usuario="root",
                senha="labmari",
                banco="biblioteca",
            )
            repositorio = AlunoRepository(conexao)
            repositorio.adicionar(aluno)
            resultado = True
        except Exception as erro:
            messagebox.showerror("Erro", f"Não foi possível cadastrar o aluno.\n{erro}")
            return

        # Mostra mensagem de sucesso ou erro
        ut.exibir_mensagem(resultado, "Aluno cadastrado com sucesso!", "Erro ao cadastrar aluno.")

        # Limpa campos se salvou com sucesso
        if resultado:
            self.limpar_campos()
