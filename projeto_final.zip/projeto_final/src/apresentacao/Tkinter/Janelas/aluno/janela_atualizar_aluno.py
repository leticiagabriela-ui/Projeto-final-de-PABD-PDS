import tkinter as tk
from tkinter import messagebox
from src.apresentacao.Tkinter.widgets import BotaoRedondo

from src.dados.conexao_singleton import ConexaoSingleton
from src.dados.aluno_repository import AlunoRepository
from src.dominio.aluno import Aluno
import src.apresentacao.Tkinter.utils as ut


class JanelaAtualizarAluno:
    def __init__(self, janela):
        self.aluno_atual = None

        self.frame = tk.Frame(janela)
        self.frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)

        tk.Label(self.frame, text="Atualizar Aluno", font=("Arial", 14, "bold")).grid(
            row=0, column=0, columnspan=3, pady=(0, 15)
        )

        tk.Label(self.frame, text="Matrícula do Aluno:").grid(row=1, column=0, sticky='E', padx=5, pady=5)
        self.entrada_matricula_busca = tk.Entry(self.frame)
        self.entrada_matricula_busca.grid(row=1, column=1, sticky='W', padx=5, pady=5)
        BotaoRedondo(self.frame, text="Buscar", command=self.buscar_aluno).grid(row=1, column=2, padx=5, pady=5)

        tk.Label(self.frame, text="Nome:").grid(row=2, column=0, sticky='E', padx=5, pady=5)
        self.entrada_nome = tk.Entry(self.frame)
        self.entrada_nome.grid(row=2, column=1, sticky='W', padx=5, pady=5)

        tk.Label(self.frame, text="Email:").grid(row=3, column=0, sticky='E', padx=5, pady=5)
        self.entrada_email = tk.Entry(self.frame)
        self.entrada_email.grid(row=3, column=1, sticky='W', padx=5, pady=5)

        BotaoRedondo(self.frame, text="Salvar Alterações", command=self.atualizar_aluno).grid(
            row=4, column=0, columnspan=3, padx=5, pady=10
        )

        self.entrada_matricula_busca.focus()

    def limpar_campos_dados(self):
        self.entrada_nome.delete(0, 'end')
        self.entrada_email.delete(0, 'end')

    def preencher_campos(self, aluno):
        self.limpar_campos_dados()
        self.entrada_nome.insert(0, aluno.nome)
        self.entrada_email.insert(0, aluno.email)

    def buscar_aluno(self):
        matricula = self.entrada_matricula_busca.get().strip()
        if not matricula:
            messagebox.showwarning("Atenção", "Informe a matrícula do aluno.")
            return

        try:
            conexao = ConexaoSingleton.obter_conexao(
                tipo_banco="mysql",
                host="127.0.0.1",
                porta=3306,
                usuario="root",
                senha="labmari",
                banco="biblioteca",
            )
            repositorio = AlunoRepository(conexao)
            aluno = repositorio.buscar_por_matricula(matricula)
        except Exception as erro:
            messagebox.showerror("Erro", f"Não foi possível buscar o aluno.\n{erro}")
            return

        if aluno is None:
            messagebox.showwarning("Atenção", "Aluno não encontrado.")
            self.aluno_atual = None
            self.limpar_campos_dados()
            return

        self.aluno_atual = aluno
        self.preencher_campos(aluno)

    def atualizar_aluno(self):
        if self.aluno_atual is None:
            messagebox.showwarning("Atenção", "Busque um aluno pela matrícula antes de salvar.")
            return

        nome = self.entrada_nome.get().strip()
        email = self.entrada_email.get().strip()

        if not nome or not email:
            messagebox.showwarning("Atenção", "Preencha todos os campos!")
            return

        aluno = Aluno(matricula=self.aluno_atual.matricula, nome=nome, email=email)

        resultado = False
        try:
            conexao = ConexaoSingleton.obter_conexao(
                tipo_banco="mysql",
                host="127.0.0.1",
                porta=3306,
                usuario="root",
                senha="labinfo",
                banco="biblioteca",
            )
            repositorio = AlunoRepository(conexao)
            resultado = repositorio.atualizar(aluno)
        except Exception as erro:
            messagebox.showerror("Erro", f"Não foi possível atualizar o aluno.\n{erro}")
            return

        ut.exibir_mensagem(resultado, "Aluno atualizado com sucesso!", "Erro ao atualizar aluno.")

        if resultado:
            self.aluno_atual = aluno
