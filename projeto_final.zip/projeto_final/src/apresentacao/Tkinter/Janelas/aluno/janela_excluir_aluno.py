import tkinter as tk
from tkinter import messagebox
from src.apresentacao.Tkinter.widgets import BotaoRedondo

from src.dados.conexao_singleton import ConexaoSingleton
from src.dados.aluno_repository import AlunoRepository
import src.apresentacao.Tkinter.utils as ut


class JanelaExcluirAluno:
    def __init__(self, janela):
        self.frame = tk.Frame(janela)
        self.frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)

        tk.Label(self.frame, text="Excluir Aluno", font=("Arial", 14, "bold")).grid(
            row=0, column=0, columnspan=2, pady=(0, 15)
        )

        tk.Label(self.frame, text="Matrícula do Aluno:").grid(row=1, column=0, sticky='E', padx=5, pady=5)
        self.entrada_matricula = tk.Entry(self.frame)
        self.entrada_matricula.grid(row=1, column=1, sticky='W', padx=5, pady=5)

        BotaoRedondo(self.frame, text="Excluir", command=self.excluir_aluno).grid(
            row=2, column=0, columnspan=2, padx=5, pady=10
        )

        self.entrada_matricula.focus()

    def excluir_aluno(self):
        matricula = self.entrada_matricula.get().strip()
        if not matricula:
            messagebox.showwarning("Atenção", "Informe a matrícula do aluno.")
            return

        confirmar = messagebox.askyesno(
            "Confirmar", f"Tem certeza que deseja excluir o aluno com matrícula {matricula}?"
        )
        if not confirmar:
            return

        resultado = False
        try:
            conexao = ConexaoSingleton.obter_conexao(
                tipo_banco="mysql",
                host="127.0.0.1",
                porta=3306,
                usuario="root",
                senha="labmari",
                banco="biblioteca",
            )
            repositorio = AlunoRepository(conexao)
            resultado = repositorio.remover(matricula)
        except Exception as erro:
            messagebox.showerror("Erro", f"Não foi possível excluir o aluno.\n{erro}")
            return

        ut.exibir_mensagem(resultado, "Aluno excluído com sucesso!", "Aluno não encontrado.")

        if resultado:
            self.entrada_matricula.delete(0, 'end')
            self.entrada_matricula.focus()
