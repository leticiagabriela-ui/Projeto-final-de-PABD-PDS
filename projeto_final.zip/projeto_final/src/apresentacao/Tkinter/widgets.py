"""Tema escuro e widgets customizados para a interface Tkinter do sistema.

Este módulo concentra:
  - a paleta de cores do tema escuro;
  - `aplicar_tema_escuro`, que configura toda a aplicação (fundo preto,
    textos claros, campos de entrada e tabelas com o novo visual);
  - `BotaoRedondo`, um botão desenhado em Canvas com cantos totalmente
    arredondados (efeito "pill"), usado no lugar do tk.Button padrão.
"""

import tkinter as tk
from tkinter import ttk

# ---------------------------------------------------------------------------
# Paleta de cores
# ---------------------------------------------------------------------------
COR_FUNDO = "#121212"              # cinza bem escuro - fundo geral da aplicação
COR_FUNDO_MENU = "#000000"         # menu lateral (preto)
COR_FUNDO_CAMPO = "#1e1e1e"        # fundo de Entry / Listbox / Treeview
COR_BORDA_CAMPO = "#333333"

COR_TEXTO = "#ffffff"
COR_TEXTO_SECUNDARIO = "#b3b3b3"

COR_BOTAO = "#2563eb"              # azul principal dos botões
COR_BOTAO_HOVER = "#3b82f6"
COR_BOTAO_TEXTO = "#ffffff"

COR_BOTAO_PERIGO = "#dc2626"
COR_BOTAO_PERIGO_HOVER = "#ef4444"

COR_BOTAO_DESABILITADO = "#4b5563"
COR_BOTAO_DESABILITADO_TEXTO = "#9ca3af"

COR_DESTAQUE = "#2563eb"


def aplicar_tema_escuro(janela):
    """Aplica o tema escuro em toda a janela raiz (via option_add) e no ttk."""

    janela.configure(bg=COR_FUNDO)

    # Widgets clássicos do tk (Frame, Label, LabelFrame, etc.)
    janela.option_add("*Background", COR_FUNDO)
    janela.option_add("*Foreground", COR_TEXTO)
    janela.option_add("*Label.Background", COR_FUNDO)
    janela.option_add("*Label.Foreground", COR_TEXTO)
    janela.option_add("*Frame.Background", COR_FUNDO)
    janela.option_add("*LabelFrame.Background", COR_FUNDO)
    janela.option_add("*LabelFrame.Foreground", COR_TEXTO)

    # Campos de entrada
    janela.option_add("*Entry.Background", COR_FUNDO_CAMPO)
    janela.option_add("*Entry.Foreground", COR_TEXTO)
    janela.option_add("*Entry.insertBackground", COR_TEXTO)
    janela.option_add("*Entry.disabledBackground", COR_FUNDO_CAMPO)
    janela.option_add("*Entry.disabledForeground", COR_TEXTO_SECUNDARIO)
    janela.option_add("*Entry.highlightBackground", COR_BORDA_CAMPO)
    janela.option_add("*Entry.highlightColor", COR_BOTAO)
    janela.option_add("*Entry.relief", "flat")

    janela.option_add("*Listbox.Background", COR_FUNDO_CAMPO)
    janela.option_add("*Listbox.Foreground", COR_TEXTO)

    # Caixas de mensagem (messagebox) usam os widgets clássicos acima também.

    # ttk (usado para Treeview / Combobox nas telas de consulta)
    estilo = ttk.Style(janela)
    try:
        estilo.theme_use("clam")
    except tk.TclError:
        pass

    estilo.configure(
        "Treeview",
        background=COR_FUNDO_CAMPO,
        fieldbackground=COR_FUNDO_CAMPO,
        foreground=COR_TEXTO,
        rowheight=24,
        borderwidth=0,
    )
    estilo.map("Treeview", background=[("selected", COR_DESTAQUE)])
    estilo.configure(
        "Treeview.Heading",
        background=COR_FUNDO_MENU,
        foreground=COR_TEXTO,
        relief="flat",
    )
    estilo.map("Treeview.Heading", background=[("active", COR_DESTAQUE)])

    # Combobox
    estilo.configure(
        "TCombobox",
        fieldbackground=COR_FUNDO_CAMPO,
        background=COR_FUNDO_CAMPO,
        foreground=COR_TEXTO,
        arrowcolor=COR_TEXTO,
    )
    estilo.map(
        "TCombobox",
        fieldbackground=[("readonly", COR_FUNDO_CAMPO), ("disabled", COR_FUNDO_MENU)],
        foreground=[("readonly", COR_TEXTO), ("disabled", COR_TEXTO_SECUNDARIO)],
        selectbackground=[("readonly", COR_FUNDO_CAMPO)],
        selectforeground=[("readonly", COR_TEXTO)],
    )


class BotaoRedondo(tk.Canvas):
    """Botão com cantos totalmente arredondados, desenhado em um Canvas.

    Interface compatível com o essencial de tk.Button: aceita `text`,
    `command`, `width` (em caracteres, aproximado), `state` e pode ser
    reconfigurado depois via `.configure(text=..., state=...)`.
    """

    def __init__(
        self,
        master,
        text="",
        command=None,
        width= None,
        height=38,
        font=("Georgia", 11, "bold"),
        bg=None,
        cor_botao=COR_BOTAO,
        cor_hover=COR_BOTAO_HOVER,
        cor_texto=COR_BOTAO_TEXTO,
        state="normal",
        **kwargs
    ):
        fundo = bg
        if fundo is None:
            try:
                fundo = master.cget("bg")
            except Exception:
                fundo = COR_FUNDO

        self._comando = command
        self._texto = text
        self._fonte = font
        self._cor_botao = cor_botao
        self._cor_hover = cor_hover
        self._cor_texto = cor_texto
        self._estado = state

        texto_len = max(len(text), 1)
        if width is None:
            largura_px = texto_len * 11 + 50
        elif width <= 60:
            # Compatibilidade com o uso antigo de tk.Button(width=N em caracteres)
            largura_px = width * 11 + 40
        else:
            largura_px = width
        self._largura = largura_px
        self._altura = height

        super().__init__(
            master,
            width=self._largura,
            height=self._altura,
            bg=fundo,
            highlightthickness=0,
            bd=0,
        )

        self._id_forma = None
        self._id_texto = None
        self._desenhar()

        self.bind("<Enter>", self._ao_entrar)
        self.bind("<Leave>", self._ao_sair)
        self.bind("<Button-1>", self._ao_clicar)

    @staticmethod
    def _pontos_arredondados(x1, y1, x2, y2, raio):
        return [
            x1 + raio, y1,
            x2 - raio, y1,
            x2, y1,
            x2, y1 + raio,
            x2, y2 - raio,
            x2, y2,
            x2 - raio, y2,
            x1 + raio, y2,
            x1, y2,
            x1, y2 - raio,
            x1, y1 + raio,
            x1, y1,
        ]

    def _desenhar(self):
        self.delete("all")
        raio = self._altura / 2
        desabilitado = self._estado == "disabled"
        cor = COR_BOTAO_DESABILITADO if desabilitado else self._cor_botao
        cor_texto = COR_BOTAO_DESABILITADO_TEXTO if desabilitado else self._cor_texto

        pontos = self._pontos_arredondados(1, 1, self._largura - 1, self._altura - 1, raio)
        self._id_forma = self.create_polygon(pontos, smooth=True, fill=cor, outline=cor)
        self._id_texto = self.create_text(
            self._largura / 2, self._altura / 2, text=self._texto, fill=cor_texto, font=self._fonte
        )

    def _ao_entrar(self, _evento):
        if self._estado == "disabled":
            return
        self.itemconfig(self._id_forma, fill=self._cor_hover, outline=self._cor_hover)
        self.configure(cursor="hand2")

    def _ao_sair(self, _evento):
        if self._estado == "disabled":
            return
        self.itemconfig(self._id_forma, fill=self._cor_botao, outline=self._cor_botao)

    def _ao_clicar(self, _evento):
        if self._estado == "disabled" or self._comando is None:
            return
        self._comando()

    def configure(self, **kwargs):
        precisa_redesenhar = False

        if "text" in kwargs:
            self._texto = kwargs.pop("text")
            if self._id_texto is not None:
                self.itemconfig(self._id_texto, text=self._texto)

        if "state" in kwargs:
            self._estado = kwargs.pop("state")
            precisa_redesenhar = True

        if "command" in kwargs:
            self._comando = kwargs.pop("command")

        if kwargs:
            super().configure(**kwargs)

        if precisa_redesenhar:
            self._desenhar()

    config = configure
