from src.negocio.livro_service import LivroService
from src.negocio.aluno_service import AlunoService
from src.negocio.emprestimo_service import EmprestimoService


class InterfaceTerminal:
    """Camada apresentação: conversa com o usuário pelo terminal."""

    def __init__(
        self,
        servico_livro: LivroService,
        servico_aluno: AlunoService,
        servico_emprestimo: EmprestimoService,
    ) -> None:
        self.servico_livro = servico_livro
        self.servico_aluno = servico_aluno
        self.servico_emprestimo = servico_emprestimo

    # ---------------- Menu principal ----------------

    def executar(self) -> None:
        while True:
            self._mostrar_menu_principal()
            opcao = input("Escolha uma opção: ").strip()
            print()

            try:
                if opcao == "1":
                    self._menu_livro()
                elif opcao == "2":
                    self._menu_aluno()
                elif opcao == "3":
                    self._menu_emprestimo()
                elif opcao == "0":
                    print("Encerrando o programa...")
                    break
                else:
                    print("Opção inválida. Tente novamente.")
            except ValueError as erro:
                print(f"Erro: {erro}")
            except Exception as erro:
                print(f"Erro inesperado: {erro}")

            print("\n" + "-" * 50 + "\n")

    @staticmethod
    def _mostrar_menu_principal() -> None:
        print("=" * 50)
        print("SISTEMA DE BIBLIOTECA")
        print("=" * 50)
        print("1 - Livros")
        print("2 - Alunos")
        print("3 - Empréstimos")
        print("0 - Sair")
        print("=" * 50)

    # ---------------- Livro ----------------

    def _menu_livro(self) -> None:
        while True:
            print("=" * 50)
            print("LIVROS")
            print("=" * 50)
            print("1 - Cadastrar livro")
            print("2 - Listar livros")
            print("3 - Buscar livro por título")
            print("4 - Atualizar livro")
            print("5 - Remover livro")
            print("0 - Voltar")
            print("=" * 50)

            opcao = input("Escolha uma opção: ").strip()
            print()

            try:
                if opcao == "1":
                    self._cadastrar_livro()
                elif opcao == "2":
                    self._listar_livros()
                elif opcao == "3":
                    self._buscar_livro_por_titulo()
                elif opcao == "4":
                    self._atualizar_livro()
                elif opcao == "5":
                    self._remover_livro()
                elif opcao == "0":
                    break
                else:
                    print("Opção inválida. Tente novamente.")
            except ValueError as erro:
                print(f"Erro: {erro}")
            except Exception as erro:
                print(f"Erro inesperado: {erro}")

            print("\n" + "-" * 50 + "\n")

    def _cadastrar_livro(self) -> None:
        titulo = input("Título: ")
        isbn = input("ISBN: ")
        autor = input("Autor: ")
        ano_publicacao = self._ler_inteiro("Ano de publicação: ")
        quantidade = self._ler_inteiro("Quantidade: ")
        genero = input("Gênero: ")
        editora = input("Editora: ")

        livro = self.servico_livro.cadastrar_livro(
            titulo, isbn, autor, ano_publicacao, quantidade, genero, editora
        )
        print(f"Livro '{livro.titulo}' cadastrado com sucesso.")

    def _listar_livros(self) -> None:
        livros = self.servico_livro.listar_livros()
        if not livros:
            print("Nenhum livro cadastrado.")
            return

        print("Livros cadastrados:")
        for livro in livros:
            print(
                f"Título: {livro.titulo} | ISBN: {livro.isbn} | "
                f"Autor: {livro.autor} | Ano: {livro.ano_publicacao} | "
                f"Quantidade: {livro.quantidade} | Gênero: {livro.genero} | Editora: {livro.editora}"
            )

    def _buscar_livro_por_titulo(self) -> None:
        titulo = input("Informe o título do livro: ")
        livro = self.servico_livro.buscar_livro_por_titulo(titulo)

        if livro is None:
            print("Livro não encontrado.")
            return

        print(f"Título: {livro.titulo}")
        print(f"ISBN: {livro.isbn}")
        print(f"Autor: {livro.autor}")
        print(f"Ano de publicação: {livro.ano_publicacao}")
        print(f"Quantidade: {livro.quantidade}")
        print(f"Gênero: {livro.genero}")
        print(f"Editora: {livro.editora}")

    def _atualizar_livro(self) -> None:
        titulo = input("Informe o título do livro a ser atualizado: ")
        isbn = input("Novo ISBN: ")
        autor = input("Novo autor: ")
        ano_publicacao = self._ler_inteiro("Novo ano de publicação: ")
        quantidade = self._ler_inteiro("Nova quantidade: ")
        genero = input("Novo gênero: ")
        editora = input("Nova editora: ")

        foi_atualizado = self.servico_livro.atualizar_livro(
            titulo, isbn, autor, ano_publicacao, quantidade, genero, editora
        )
        if foi_atualizado:
            print("Livro atualizado com sucesso.")
        else:
            print("Nenhum livro foi atualizado. Verifique o título informado.")

    def _remover_livro(self) -> None:
        titulo = input("Informe o título do livro a ser removido: ")
        foi_removido = self.servico_livro.remover_livro(titulo)
        if foi_removido:
            print("Livro removido com sucesso.")
        else:
            print("Nenhum livro foi removido. Verifique o título informado.")

    # ---------------- Aluno ----------------

    def _menu_aluno(self) -> None:
        while True:
            print("=" * 50)
            print("ALUNOS")
            print("=" * 50)
            print("1 - Cadastrar aluno")
            print("2 - Listar alunos")
            print("3 - Buscar aluno por matrícula")
            print("4 - Atualizar aluno")
            print("5 - Remover aluno")
            print("0 - Voltar")
            print("=" * 50)

            opcao = input("Escolha uma opção: ").strip()
            print()

            try:
                if opcao == "1":
                    self._cadastrar_aluno()
                elif opcao == "2":
                    self._listar_alunos()
                elif opcao == "3":
                    self._buscar_aluno_por_matricula()
                elif opcao == "4":
                    self._atualizar_aluno()
                elif opcao == "5":
                    self._remover_aluno()
                elif opcao == "0":
                    break
                else:
                    print("Opção inválida. Tente novamente.")
            except ValueError as erro:
                print(f"Erro: {erro}")
            except Exception as erro:
                print(f"Erro inesperado: {erro}")

            print("\n" + "-" * 50 + "\n")

    def _cadastrar_aluno(self) -> None:
        nome = input("Nome: ")
        matricula = input("Matrícula: ")
        email = input("Email: ")

        aluno = self.servico_aluno.cadastrar_aluno(nome, matricula, email)
        print(f"Aluno '{aluno.nome}' cadastrado com sucesso.")

    def _listar_alunos(self) -> None:
        alunos = self.servico_aluno.listar_alunos()
        if not alunos:
            print("Nenhum aluno cadastrado.")
            return

        print("Alunos cadastrados:")
        for aluno in alunos:
            print(f"Matrícula: {aluno.matricula} | Nome: {aluno.nome} | Email: {aluno.email}")

    def _buscar_aluno_por_matricula(self) -> None:
        matricula = input("Informe a matrícula do aluno: ")
        aluno = self.servico_aluno.buscar_aluno_por_matricula(matricula)

        if aluno is None:
            print("Aluno não encontrado.")
            return

        print(f"Matrícula: {aluno.matricula}")
        print(f"Nome: {aluno.nome}")
        print(f"Email: {aluno.email}")

    def _atualizar_aluno(self) -> None:
        matricula = input("Informe a matrícula do aluno a ser atualizado: ")
        nome = input("Novo nome: ")
        email = input("Novo email: ")

        foi_atualizado = self.servico_aluno.atualizar_aluno(matricula, nome, email)
        if foi_atualizado:
            print("Aluno atualizado com sucesso.")
        else:
            print("Nenhum aluno foi atualizado. Verifique a matrícula informada.")

    def _remover_aluno(self) -> None:
        matricula = input("Informe a matrícula do aluno a ser removido: ")
        foi_removido = self.servico_aluno.remover_aluno(matricula)
        if foi_removido:
            print("Aluno removido com sucesso.")
        else:
            print("Nenhum aluno foi removido. Verifique a matrícula informada.")

    # ---------------- Empréstimo ----------------

    def _menu_emprestimo(self) -> None:
        while True:
            print("=" * 50)
            print("EMPRÉSTIMOS")
            print("=" * 50)
            print("1 - Cadastrar empréstimo")
            print("2 - Listar empréstimos")
            print("3 - Buscar empréstimo por ID")
            print("4 - Atualizar empréstimo")
            print("5 - Remover empréstimo")
            print("0 - Voltar")
            print("=" * 50)

            opcao = input("Escolha uma opção: ").strip()
            print()

            try:
                if opcao == "1":
                    self._cadastrar_emprestimo()
                elif opcao == "2":
                    self._listar_emprestimos()
                elif opcao == "3":
                    self._buscar_emprestimo_por_id()
                elif opcao == "4":
                    self._atualizar_emprestimo()
                elif opcao == "5":
                    self._remover_emprestimo()
                elif opcao == "0":
                    break
                else:
                    print("Opção inválida. Tente novamente.")
            except ValueError as erro:
                print(f"Erro: {erro}")
            except Exception as erro:
                print(f"Erro inesperado: {erro}")

            print("\n" + "-" * 50 + "\n")

    def _cadastrar_emprestimo(self) -> None:
        matricula_aluno = input("Matrícula do aluno: ")
        titulo = input("Título do livro: ")
        data_emprestimo = input("Data do empréstimo (aaaa-mm-dd): ")
        data_devolucao = input("Data de devolução (aaaa-mm-dd): ")

        emprestimo = self.servico_emprestimo.cadastrar_emprestimo(
            matricula_aluno, titulo, data_emprestimo, data_devolucao
        )
        print(f"Empréstimo cadastrado com sucesso. ID gerado: {emprestimo.id}")

    def _listar_emprestimos(self) -> None:
        emprestimos = self.servico_emprestimo.listar_emprestimos()
        if not emprestimos:
            print("Nenhum empréstimo cadastrado.")
            return

        print("Empréstimos cadastrados:")
        for emprestimo in emprestimos:
            print(
                f"ID: {emprestimo.id} | Matrícula do aluno: {emprestimo.matricula_aluno} | "
                f"Título do livro: {emprestimo.titulo} | Data Empréstimo: {emprestimo.data_emprestimo} | "
                f"Data Devolução: {emprestimo.data_devolucao}"
            )

    def _buscar_emprestimo_por_id(self) -> None:
        id_emprestimo = self._ler_inteiro("Informe o ID do empréstimo: ")
        emprestimo = self.servico_emprestimo.buscar_emprestimo_por_id(id_emprestimo)

        if emprestimo is None:
            print("Empréstimo não encontrado.")
            return

        print(f"ID: {emprestimo.id}")
        print(f"Matrícula do aluno: {emprestimo.matricula_aluno}")
        print(f"Título do livro: {emprestimo.titulo}")
        print(f"Data do empréstimo: {emprestimo.data_emprestimo}")
        print(f"Data de devolução: {emprestimo.data_devolucao}")

    def _atualizar_emprestimo(self) -> None:
        id_emprestimo = self._ler_inteiro("Informe o ID do empréstimo a ser atualizado: ")
        matricula_aluno = input("Nova matrícula do aluno: ")
        titulo = input("Novo título do livro: ")
        data_emprestimo = input("Nova data do empréstimo (aaaa-mm-dd): ")
        data_devolucao = input("Nova data de devolução (aaaa-mm-dd): ")

        foi_atualizado = self.servico_emprestimo.atualizar_emprestimo(
            id_emprestimo, matricula_aluno, titulo, data_emprestimo, data_devolucao
        )
        if foi_atualizado:
            print("Empréstimo atualizado com sucesso.")
        else:
            print("Nenhum empréstimo foi atualizado. Verifique o ID informado.")

    def _remover_emprestimo(self) -> None:
        id_emprestimo = self._ler_inteiro("Informe o ID do empréstimo a ser removido: ")
        foi_removido = self.servico_emprestimo.remover_emprestimo(id_emprestimo)
        if foi_removido:
            print("Empréstimo removido com sucesso.")
        else:
            print("Nenhum empréstimo foi removido. Verifique o ID informado.")

    # ---------------- Utilitários ----------------

    @staticmethod
    def _ler_inteiro(mensagem: str) -> int:
        valor_bruto = input(mensagem).strip()
        return int(valor_bruto)
