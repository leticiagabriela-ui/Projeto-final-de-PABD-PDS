"""Configurações simples do sistema.

`SENHA_SISTEMA` é a senha única/fixa usada por todos os funcionários para
entrar no sistema (login por matrícula + esta senha). Altere o valor abaixo
para trocar a senha de acesso.
"""

SENHA_SISTEMA = "biblioteca123"
