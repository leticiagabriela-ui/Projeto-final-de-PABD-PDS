from typing import Optional

from src.dados.emprestimo_repository import EmprestimoRepository
from src.dominio.emprestimo import Emprestimo, STATUS_EMPRESTADO, STATUS_VALIDOS


class EmprestimoService:
    """Camada de negocio: aplica validacoes e regras simples.

    O empréstimo referencia um aluno (matricula_aluno) e um livro (titulo),
    conforme as foreign keys definidas em banco_de_dados/init.sql.
    """

    def __init__(self, repositorio: EmprestimoRepository) -> None:
        self.repositorio = repositorio

    def cadastrar_emprestimo(
        self,
        matricula_aluno: str,
        titulo: str,
        data_emprestimo: str,
        data_devolucao: str,
        status: str = STATUS_EMPRESTADO,
    ) -> Emprestimo:
        matricula_limpa = matricula_aluno.strip()
        titulo_limpo = titulo.strip()
        data_emprestimo_limpa = data_emprestimo.strip()
        data_devolucao_limpa = data_devolucao.strip()
        status_limpo = status.strip().lower()

        if not matricula_limpa:
            raise ValueError("A matrícula do aluno não pode ficar vazia.")

        if not titulo_limpo:
            raise ValueError("O título do livro não pode ficar vazio.")

        if not data_emprestimo_limpa:
            raise ValueError("A data de empréstimo não pode ficar vazia.")

        if not data_devolucao_limpa:
            raise ValueError("A data de devolução não pode ficar vazia.")

        if status_limpo not in STATUS_VALIDOS:
            raise ValueError(
                f"Status inválido. Valores aceitos: {', '.join(STATUS_VALIDOS)}."
            )

        emprestimo = Emprestimo(
            matricula_aluno=matricula_limpa,
            titulo=titulo_limpo,
            data_emprestimo=data_emprestimo_limpa,
            data_devolucao=data_devolucao_limpa,
            status=status_limpo,
        )

        novo_id = self.repositorio.adicionar(emprestimo)
        emprestimo.id = novo_id

        return emprestimo

    def listar_emprestimos(self) -> list[Emprestimo]:
        return self.repositorio.listar_todos()

    def buscar_emprestimo_por_id(self, id_emprestimo: int) -> Optional[Emprestimo]:
        if id_emprestimo <= 0:
            raise ValueError("O ID deve ser um número inteiro positivo.")

        return self.repositorio.buscar_por_id(id_emprestimo)

    def atualizar_emprestimo(
        self,
        id_emprestimo: int,
        matricula_aluno: str,
        titulo: str,
        data_emprestimo: str,
        data_devolucao: str,
        status: str = STATUS_EMPRESTADO,
    ) -> bool:
        if id_emprestimo <= 0:
            raise ValueError("O ID do empréstimo deve ser um número inteiro positivo.")

        matricula_limpa = matricula_aluno.strip()
        titulo_limpo = titulo.strip()
        data_emprestimo_limpa = data_emprestimo.strip()
        data_devolucao_limpa = data_devolucao.strip()
        status_limpo = status.strip().lower()

        if not matricula_limpa:
            raise ValueError("A matrícula do aluno não pode ficar vazia.")

        if not titulo_limpo:
            raise ValueError("O título do livro não pode ficar vazio.")

        if not data_emprestimo_limpa:
            raise ValueError("A data de empréstimo não pode ficar vazia.")

        if not data_devolucao_limpa:
            raise ValueError("A data de devolução não pode ficar vazia.")

        if status_limpo not in STATUS_VALIDOS:
            raise ValueError(
                f"Status inválido. Valores aceitos: {', '.join(STATUS_VALIDOS)}."
            )

        emprestimo = Emprestimo(
            id=id_emprestimo,
            matricula_aluno=matricula_limpa,
            titulo=titulo_limpo,
            data_emprestimo=data_emprestimo_limpa,
            data_devolucao=data_devolucao_limpa,
            status=status_limpo,
        )

        return self.repositorio.atualizar(emprestimo)

    def remover_emprestimo(self, id_emprestimo: int) -> bool:
        if id_emprestimo <= 0:
            raise ValueError("O ID deve ser um número inteiro positivo.")
        return self.repositorio.remover(id_emprestimo)
