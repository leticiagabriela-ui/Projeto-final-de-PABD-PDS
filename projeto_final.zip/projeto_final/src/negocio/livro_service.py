from typing import Optional

from src.dados.livro_repository import LivroRepository
from src.dominio.livro import Livro


class LivroService:
    """Camada de negocio: aplica validacoes e regras simples."""

    def __init__(self, repositorio: LivroRepository) -> None:
        self.repositorio = repositorio

    def cadastrar_livro(
        self,
        titulo: str,
        isbn: str,
        autor: str,
        ano_publicacao: int,
        quantidade: int,
        genero: str,
        editora: str,
    ) -> Livro:
        titulo_limpo = titulo.strip()
        isbn_limpo = isbn.strip()
        autor_limpo = autor.strip()
        genero_limpo = genero.strip()
        editora_limpa = editora.strip()

        if not titulo_limpo:
            raise ValueError("O título do livro não pode ficar vazio.")

        if not isbn_limpo:
            raise ValueError("O ISBN não pode ficar vazio.")

        if not autor_limpo:
            raise ValueError("O autor não pode ficar vazio.")

        if ano_publicacao <= 0:
            raise ValueError("O ano de publicação é inválido.")

        if quantidade < 0:
            raise ValueError("A quantidade não pode ser negativa.")

        if not genero_limpo:
            raise ValueError("O gênero não pode ficar vazio.")

        if not editora_limpa:
            raise ValueError("A editora não pode ficar vazia.")

        livro = Livro(
            titulo=titulo_limpo,
            isbn=isbn_limpo,
            autor=autor_limpo,
            ano_publicacao=ano_publicacao,
            quantidade=quantidade,
            genero=genero_limpo,
            editora=editora_limpa,
        )

        self.repositorio.adicionar(livro)
        return livro

    def listar_livros(self) -> list[Livro]:
        return self.repositorio.listar_todos()

    def buscar_livro_por_titulo(self, titulo: str) -> Optional[Livro]:
        titulo_limpo = titulo.strip()
        if not titulo_limpo:
            raise ValueError("O título não pode ficar vazio.")
        return self.repositorio.buscar_por_titulo(titulo_limpo)

    def atualizar_livro(
        self,
        titulo: str,
        isbn: str,
        autor: str,
        ano_publicacao: int,
        quantidade: int,
        genero: str,
        editora: str,
    ) -> bool:
        titulo_limpo = titulo.strip()
        isbn_limpo = isbn.strip()
        autor_limpo = autor.strip()
        genero_limpo = genero.strip()
        editora_limpa = editora.strip()

        if not titulo_limpo:
            raise ValueError("O título do livro não pode ficar vazio.")

        if not isbn_limpo:
            raise ValueError("O ISBN não pode ficar vazio.")

        if not autor_limpo:
            raise ValueError("O autor não pode ficar vazio.")

        if ano_publicacao <= 0:
            raise ValueError("O ano de publicação é inválido.")

        if quantidade < 0:
            raise ValueError("A quantidade não pode ser negativa.")

        if not genero_limpo:
            raise ValueError("O gênero não pode ficar vazio.")

        if not editora_limpa:
            raise ValueError("A editora não pode ficar vazia.")

        livro = Livro(
            titulo=titulo_limpo,
            isbn=isbn_limpo,
            autor=autor_limpo,
            ano_publicacao=ano_publicacao,
            quantidade=quantidade,
            genero=genero_limpo,
            editora=editora_limpa,
        )

        return self.repositorio.atualizar(livro)

    def remover_livro(self, titulo: str) -> bool:
        titulo_limpo = titulo.strip()
        if not titulo_limpo:
            raise ValueError("O título não pode ficar vazio.")
        return self.repositorio.remover(titulo_limpo)
