from typing import Optional

from src.dados.aluno_repository import AlunoRepository
from src.dominio.aluno import Aluno


class AlunoService:
    """Camada de negocio: aplica validacoes e regras simples."""

    def __init__(self, repositorio: AlunoRepository) -> None:
        self.repositorio = repositorio

    def cadastrar_aluno(self, nome: str, matricula: str, email: str) -> Aluno:
        nome_limpo = nome.strip()
        matricula_limpa = matricula.strip()
        email_limpo = email.strip()

        if not nome_limpo:
            raise ValueError("O nome do aluno não pode ficar vazio.")

        if not matricula_limpa:
            raise ValueError("A matrícula não pode ficar vazia.")

        if not email_limpo:
            raise ValueError("O email não pode ficar vazio.")

        aluno = Aluno(nome=nome_limpo, matricula=matricula_limpa, email=email_limpo)
        self.repositorio.adicionar(aluno)
        return aluno

    def listar_alunos(self) -> list[Aluno]:
        return self.repositorio.listar_todos()

    def buscar_aluno_por_matricula(self, matricula: str) -> Optional[Aluno]:
        matricula_limpa = matricula.strip()
        if not matricula_limpa:
            raise ValueError("A matrícula não pode ficar vazia.")
        return self.repositorio.buscar_por_matricula(matricula_limpa)

    def atualizar_aluno(self, matricula: str, nome: str, email: str) -> bool:
        matricula_limpa = matricula.strip()
        nome_limpo = nome.strip()
        email_limpo = email.strip()

        if not matricula_limpa:
            raise ValueError("A matrícula não pode ficar vazia.")

        if not nome_limpo:
            raise ValueError("O nome do aluno não pode ficar vazio.")

        if not email_limpo:
            raise ValueError("O email não pode ficar vazio.")

        aluno = Aluno(nome=nome_limpo, matricula=matricula_limpa, email=email_limpo)
        return self.repositorio.atualizar(aluno)

    def remover_aluno(self, matricula: str) -> bool:
        matricula_limpa = matricula.strip()
        if not matricula_limpa:
            raise ValueError("A matrícula não pode ficar vazia.")
        return self.repositorio.remover(matricula_limpa)
