from typing import Optional

from src.dados.funcionario_repository import FuncionarioRepository
from src.dominio.funcionario import Funcionario


class FuncionarioService:
    """Camada de negocio: aplica validacoes e regras simples."""

    def __init__(self, repositorio: FuncionarioRepository) -> None:
        self.repositorio = repositorio

    def cadastrar_funcionario(self, nome: str, matricula: str, email: str) -> Funcionario:
        nome_limpo = nome.strip()
        matricula_limpa = matricula.strip()
        email_limpo = email.strip()

        if not nome_limpo:
            raise ValueError("O nome do funcionário não pode ficar vazio.")

        if not matricula_limpa:
            raise ValueError("A matrícula não pode ficar vazia.")

        funcionario = Funcionario(nome=nome_limpo, matricula=matricula_limpa, email=email_limpo)
        self.repositorio.adicionar(funcionario)
        return funcionario

    def listar_funcionarios(self) -> list[Funcionario]:
        return self.repositorio.listar_todos()

    def buscar_funcionario_por_matricula(self, matricula: str) -> Optional[Funcionario]:
        matricula_limpa = matricula.strip()
        if not matricula_limpa:
            raise ValueError("A matrícula não pode ficar vazia.")
        return self.repositorio.buscar_por_matricula(matricula_limpa)

    def atualizar_funcionario(self, matricula: str, nome: str, email: str) -> bool:
        matricula_limpa = matricula.strip()
        nome_limpo = nome.strip()

        if not matricula_limpa:
            raise ValueError("A matrícula não pode ficar vazia.")

        if not nome_limpo:
            raise ValueError("O nome do funcionário não pode ficar vazio.")

        funcionario = Funcionario(nome=nome_limpo, matricula=matricula_limpa, email=email.strip())
        return self.repositorio.atualizar(funcionario)

    def remover_funcionario(self, matricula: str) -> bool:
        matricula_limpa = matricula.strip()
        if not matricula_limpa:
            raise ValueError("A matrícula não pode ficar vazia.")
        return self.repositorio.remover(matricula_limpa)
