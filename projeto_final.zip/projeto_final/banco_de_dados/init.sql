CREATE DATABASE IF NOT EXISTS biblioteca;
USE biblioteca;

CREATE TABLE IF NOT EXISTS livro (
    titulo VARCHAR(100) NOT NULL PRIMARY KEY,
    isbn VARCHAR(20) NOT NULL,
    autor VARCHAR(100) NOT NULL,
    ano_publicacao INT,
    quantidade INT NOT NULL,
    genero VARCHAR(50),
    editora VARCHAR(100) NOT NULL
);

CREATE TABLE IF NOT EXISTS funcionario (
    nome VARCHAR(100) NOT NULL,
    matricula_funcionario VARCHAR(50) NOT NULL PRIMARY KEY,
    email VARCHAR(100)
);

CREATE TABLE IF NOT EXISTS aluno (
    matricula_aluno VARCHAR(15) NOT NULL PRIMARY KEY,
    nome_aluno VARCHAR(100) NOT NULL,
    email VARCHAR(50) NOT NULL
);

CREATE TABLE IF NOT EXISTS emprestimo (
    id INT AUTO_INCREMENT PRIMARY KEY,
    matricula_aluno VARCHAR(15),
    titulo VARCHAR(100),
    data_emprestimo DATE,
    data_devolucao DATE,
    status ENUM('devolvido', 'emprestado', 'atrasado', 'cancelado') NOT NULL DEFAULT 'emprestado',
    FOREIGN KEY (matricula_aluno) REFERENCES aluno(matricula_aluno),
    FOREIGN KEY (titulo) REFERENCES livro(titulo)
);