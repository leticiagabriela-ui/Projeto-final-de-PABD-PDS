
import tkinter as tk
from tkinter import font as tkfont

from src.apresentacao.Tkinter.widgets import BotaoRedondo, aplicar_tema_escuro, COR_FUNDO, COR_FUNDO_MENU

from src.apresentacao.Tkinter.Janelas.livro.janela_cadastrar_livro import JanelaCadastroLivro
from src.apresentacao.Tkinter.Janelas.livro.janela_atualizar_livro import JanelaAtualizarLivro
from src.apresentacao.Tkinter.Janelas.livro.janela_excluir_livro import JanelaExcluirLivro
from src.apresentacao.Tkinter.Janelas.livro.janela_consultar_livro import JanelaConsultarLivro

from src.apresentacao.Tkinter.Janelas.aluno.janela_cadastrar_aluno import JanelaCadastroAluno
from src.apresentacao.Tkinter.Janelas.aluno.janela_atualizar_aluno import JanelaAtualizarAluno
from src.apresentacao.Tkinter.Janelas.aluno.janela_excluir_aluno import JanelaExcluirAluno
from src.apresentacao.Tkinter.Janelas.aluno.janela_consultar_aluno import JanelaConsultarAluno

from src.apresentacao.Tkinter.Janelas.emprestimo.Janela_cadastrar_emprestimo import JanelaCadastroEmprestimo
from src.apresentacao.Tkinter.Janelas.emprestimo.Janela_atualizar_emprestimo import JanelaAtualizarEmprestimo
from src.apresentacao.Tkinter.Janelas.emprestimo.Janela_excluir_emprestimo import JanelaExcluirEmprestimo
from src.apresentacao.Tkinter.Janelas.emprestimo.Janela_consultar_emprestimo import JanelaConsultarEmprestimo

from src.apresentacao.Tkinter.Janelas.usuario.janela_login import JanelaLogin


class JanelaPrincipal:

   
    FONTE_TITULO = "Georgia"

    def __init__(self):
        self.janela = tk.Tk()
        self.janela.title("Sistema de Biblioteca")
        self.janela.geometry("1000x600")

        fonte_padrao = tkfont.nametofont("TkDefaultFont")
        fonte_padrao.configure(family="Georgia", size=11)
        self.janela.option_add("*Font", fonte_padrao)

        aplicar_tema_escuro(self.janela)

        self.funcionario_logado = None

        # Tela de login
        self.frame_login = tk.Frame(self.janela)
        self.frame_login.pack(fill="both", expand=True)
        JanelaLogin(self.frame_login, ao_autenticar=self.iniciar_menu_principal)

        self.janela.mainloop()

    def iniciar_menu_principal(self, funcionario_logado):
        self.funcionario_logado = funcionario_logado
        self.frame_login.destroy()

        # Menu lateral
        self.frame_menu = tk.Frame(self.janela, bg=COR_FUNDO_MENU, width=200)
        self.frame_menu.pack(side="left", fill="y")

        # Área de conteúdo
        self.frame_conteudo = tk.Frame(self.janela, bg=COR_FUNDO)
        self.frame_conteudo.pack(side="right", fill="both", expand=True)

        # Título do sistema
        tk.Label(
            self.frame_menu,
            text="Biblioteca Escolar",
            bg=COR_FUNDO_MENU,
            fg="white",
            font=(self.FONTE_TITULO, 16, "bold italic")
        ).pack(pady=20)


        BotaoRedondo(
            self.frame_menu,
            text="Livros",
            bg=COR_FUNDO_MENU,
            width= 13,
            command=self.abrir_menu_livro
        ).pack(fill="x", padx=10, pady=5)

        BotaoRedondo(
            self.frame_menu,
            text="Alunos",
            bg=COR_FUNDO_MENU,
            width= 13,
            command=self.abrir_menu_aluno
        ).pack(fill="x", padx=10, pady=5)

        BotaoRedondo(
            self.frame_menu,
            text="Empréstimos",
            bg=COR_FUNDO_MENU,
            width= 13,
            command=self.abrir_menu_emprestimo
        ).pack(fill="x", padx=10, pady=5)

        BotaoRedondo(
            self.frame_menu,
            text="Sair",
            bg=COR_FUNDO_MENU,
            width= 13,
            command=self.janela.quit
        ).pack(fill="x", padx=10, pady=20)

        self.abrir_painel()

    def limpar_widgets(self):
        for widget in self.frame_conteudo.winfo_children():
            widget.destroy()

    def abrir_painel(self):
        self.limpar_widgets()
        tk.Label(
            self.frame_conteudo,
            font=(self.FONTE_TITULO, 20, "bold italic")
        ).pack(pady=20)

    def abrir_submenu(self, titulo, opcoes):
        """Mostra uma tela com botões para Cadastrar/Atualizar/Excluir/Consultar."""
        self.limpar_widgets()

        frame_submenu = tk.Frame(self.frame_conteudo)
        frame_submenu.place(relx=0.5, rely=0.5, anchor=tk.CENTER)

        tk.Label(
            frame_submenu,
            text=titulo,
            font=(self.FONTE_TITULO, 18, "bold italic")
        ).pack(pady=(0, 20))

        for texto, comando in opcoes:
            BotaoRedondo(
                frame_submenu,
                text=texto,
                width=30,
                command=comando
            ).pack(pady=5)

    # Livro 

    def abrir_menu_livro(self):
        self.abrir_submenu("Livros", [
            ("Cadastrar Livro", self.abrir_janela_cadastro_livro),
            ("Excluir Livro", self.abrir_janela_excluir_livro),
            ("Consultar Livro", self.abrir_janela_consultar_livro),
        ])

    def abrir_janela_cadastro_livro(self):
        self.limpar_widgets()
        JanelaCadastroLivro(self.frame_conteudo)

    def abrir_janela_excluir_livro(self):
        self.limpar_widgets()
        JanelaExcluirLivro(self.frame_conteudo)

    def abrir_janela_consultar_livro(self):
        self.limpar_widgets()
        JanelaConsultarLivro(self.frame_conteudo)

    #  Aluno

    def abrir_menu_aluno(self):
        self.abrir_submenu("Alunos", [
            ("Cadastrar Aluno", self.abrir_janela_cadastro_aluno),
            ("Excluir Aluno", self.abrir_janela_excluir_aluno),
            ("Consultar Aluno", self.abrir_janela_consultar_aluno),
        ])

    def abrir_janela_cadastro_aluno(self):
        self.limpar_widgets()
        JanelaCadastroAluno(self.frame_conteudo)

    def abrir_janela_excluir_aluno(self):
        self.limpar_widgets()
        JanelaExcluirAluno(self.frame_conteudo)

    def abrir_janela_consultar_aluno(self):
        self.limpar_widgets()
        JanelaConsultarAluno(self.frame_conteudo)

    # Empréstimo 

    def abrir_menu_emprestimo(self):
        self.abrir_submenu("Empréstimos", [
            ("Cadastrar Empréstimo", self.abrir_janela_cadastro_emprestimo),
            ("Consultar Empréstimo", self.abrir_janela_consultar_emprestimo),
        ])

    def abrir_janela_cadastro_emprestimo(self):
        self.limpar_widgets()
        JanelaCadastroEmprestimo(self.frame_conteudo)

    def abrir_janela_consultar_emprestimo(self):
        self.limpar_widgets()
        JanelaConsultarEmprestimo(self.frame_conteudo)


JanelaPrincipal()
